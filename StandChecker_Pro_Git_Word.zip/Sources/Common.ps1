﻿$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$script:Checks=New-Object System.Collections.Generic.List[object]
$script:Uncertain=New-Object System.Collections.Generic.List[string]
$script:Inv=[System.Globalization.CultureInfo]::InvariantCulture
$script:LastDbCodes=@{}
$script:Cfg=@{NodeRedUrl='http://192.168.30.10:1880';CtrlUrl='http://192.168.20.10:8080';DbUrl='http://192.168.20.20:8081';PrometheusUrl='http://192.168.20.30:9090';GrafanaUrl='http://192.168.20.30:3000';Threshold=30;Comparison='ge';ObserveSeconds=20;SampleInterval=5;TimeoutSeconds=4;ExpectedPeriod=5;MaxSensorAge=20;FanWaitSeconds=45}
function Prop($o,[string]$k,$default=$null){
 if($null -eq $o){return $default}
 if($o -is [System.Collections.IDictionary]){foreach($key in $o.Keys){if([string]$key -ceq $k){return $o[$key]}};return $default}
 foreach($p in $o.PSObject.Properties){if($p.Name -ceq $k){return $p.Value}}
 return $default
}
function Has($o,$k){$sentinel=New-Object object;return -not [object]::ReferenceEquals((Prop $o $k $sentinel),$sentinel)}
function Check([string]$area,[string]$name,[string]$status,[string]$detail){
 [void]$script:Checks.Add([pscustomobject]@{Area=$area;Check=$name;Status=$status;Detail=$detail})
 Write-Host ('[{0}] {1}: {2} - {3}' -f $status,$area,$name,$detail)
}
function Num($x){$n=0.0;if($null -eq $x -or $x -is [bool]){return $null};if([double]::TryParse([string]$x,[System.Globalization.NumberStyles]::Float,$script:Inv,[ref]$n) -and -not [double]::IsNaN($n) -and -not [double]::IsInfinity($n)){return $n};return $null}
function NewMap {return New-Object 'System.Collections.Generic.Dictionary[string,object]' ([System.StringComparer]::Ordinal)}
function AsMap($x){
 if($null -eq $x){return $null}
 if($x -is [ValueType] -or $x -is [string]){return $x}
 if($x -is [System.Collections.IDictionary]){$m=NewMap;foreach($k in $x.Keys){$m[[string]$k]=AsMap $x[$k]};return $m}
 if($x -is [pscustomobject]){$m=NewMap;foreach($p in $x.PSObject.Properties){$m[$p.Name]=AsMap $p.Value};return $m}
 if($x -is [array]){$a=@();foreach($v in $x){$a+=,(AsMap $v)};return ,$a};return $x
}
function Clone($x){return AsMap (($x|ConvertTo-Json -Depth 50 -Compress)|ConvertFrom-Json)}
function GetPath($o,[string]$path){$v=$o;foreach($k in $path.Split('.')){$v=Prop $v $k};return $v}
function SetPath($o,[string]$path,$value){$parts=$path.Split('.');$v=$o;for($i=0;$i -lt $parts.Length-1;$i++){if(-not (Prop $v $parts[$i]) -or -not ((Prop $v $parts[$i]) -is [System.Collections.IDictionary])){$v[$parts[$i]]=NewMap};$v=$v[$parts[$i]]};$v[$parts[-1]]=$value}
function DelPath($o,[string]$path){$a=$path.Split('.');$v=$o;for($i=0;$i -lt $a.Length-1;$i++){$v=Prop $v $a[$i];if($null -eq $v){return}};if($v -is [System.Collections.IDictionary]){[void]$v.Remove($a[-1])}}
function Typed($value,[string]$type,$msg){
 switch -CaseSensitive ($type){
 'str' {return [string]$value}
 'num' {return Num $value}
 'bool' {return [string]$value -ceq 'true'}
 'json' {try{return AsMap ([string]$value|ConvertFrom-Json)}catch{throw 'Invalid JSON in a typed field'}}
 'date' {return [double][DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}
 'msg' {return Clone (GetPath $msg ([string]$value))}
 'null' {return $null}
 default {throw ('Unsupported value type: '+$type)}
 }
}
function ValidBase([string]$value){$u=$null;if(-not [uri]::TryCreate($value,[UriKind]::Absolute,[ref]$u) -or $u.Scheme -notin @('http','https') -or $u.UserInfo -or $u.Query -or $u.Fragment){throw 'Use an absolute http(s) base URL without credentials, query or fragment.'};return $value.TrimEnd('/')}
function Http([string]$url,[hashtable]$headers=@{}){
 $resp=$null
 try{
  $req=[System.Net.HttpWebRequest]::Create($url);$req.Method='GET';$req.Timeout=[int]$script:Cfg.TimeoutSeconds*1000;$req.ReadWriteTimeout=$req.Timeout;$req.AllowAutoRedirect=$false;$req.Proxy=$null
  foreach($k in $headers.Keys){$req.Headers[$k]=[string]$headers[$k]}
  try{$resp=$req.GetResponse()}catch [System.Net.WebException]{if($_.Exception.Response){$resp=$_.Exception.Response}else{throw}}
  $reader=New-Object System.IO.StreamReader($resp.GetResponseStream(),[System.Text.Encoding]::UTF8)
  try{$text=$reader.ReadToEnd()}finally{$reader.Dispose()}
  $obj=$null;try{$obj=$text|ConvertFrom-Json}catch{}
  return [pscustomobject]@{Code=[int]$resp.StatusCode;Text=$text;Json=$obj;Error=''}
 }catch{return [pscustomobject]@{Code=0;Text='';Json=$null;Error='Connection/timeout/TLS error'}}finally{if($resp){$resp.Close()}}
}
function ApiStatus($r){if($r.Code -in @(401,403)){return 'SKIP'};return 'FAIL'}
function Metric($text,[string]$name,[string]$label='',[string]$id=''){
 $values=@()
 foreach($line in ([string]$text -split "`n")){
  if($line -match ('^'+[regex]::Escape($name)+'(?:\{(?<labels>[^}]*)\})?\s+(?<value>\S+)')){
   $labels=$Matches['labels'];$value=$Matches['value']
   if(-not $label -or $labels -match ('(?:^|,)\s*'+[regex]::Escape($label)+'="'+[regex]::Escape($id)+'"(?:,|$)')){$values+=,(Num $value)}
  }
 }
 if($values.Count -eq 1){return $values[0]};return $null
}
function Latest([string]$id){$r=Http ($script:Cfg.DbUrl+'/api/history?device_id='+[uri]::EscapeDataString($id)+'&limit=1');$script:LastDbCodes[$id]=$r.Code;return $r}
function Row($r,[string]$id){if($r.Code -ne 200){return $null};$rows=@(Prop $r.Json 'rows' @());if($rows.Count -eq 1 -and (Prop $rows[0] 'device_id') -ceq $id){return $rows[0]};return $null}
function Canonical($o){
 if($null -eq $o){return 'null'}
 if($o -is [array]){return '['+((@($o|ForEach-Object{Canonical $_})) -join ',')+']'}
 if($o -is [System.Collections.IDictionary] -or $o -is [pscustomobject]){
  $pairs=@();$keys=@();if($o -is [System.Collections.IDictionary]){$keys=@($o.Keys)}else{$keys=@($o.PSObject.Properties.Name)}
  foreach($k in ($keys|Sort-Object -CaseSensitive)){if($k -in @('x','y','w','h','name','label','info','icon','l','credentials','rev')){continue};$pairs+=(([string]$k|ConvertTo-Json -Compress)+':'+(Canonical (Prop $o $k)))}
  return '{'+($pairs -join ',')+'}'
 };return ($o|ConvertTo-Json -Compress)
}
function Fingerprint($nodes){$canonical=Canonical @($nodes|Sort-Object {Prop $_ 'id'});$sha=[System.Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($canonical)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}}
function FlowArray($obj){if($obj -is [array]){return ,$obj};$f=Prop $obj 'flows';if($f -is [array]){return ,$f};throw 'Ожидается an array of nodes or an object with a flows array.'}
function EmitRoute($inject,$overrideValue=$null,[bool]$override=$false){
 $result=New-Object System.Collections.Generic.List[object];$msg=NewMap
 try{
  $props=@(Prop $inject 'props' @())
  if($props.Count){foreach($p in $props){$key=[string](Prop $p 'p');$typ=[string](Prop $p 'vt' '');$v=Prop $p 'v';if(-not $typ){$typ=[string](Prop $inject ($key+'Type') 'str');$v=Prop $inject $key ''};SetPath $msg $key (Typed $v $typ $msg)}}
  else{SetPath $msg 'payload' (Typed (Prop $inject 'payload' '') ([string](Prop $inject 'payloadType' 'date')) $msg)}
  if($override){if((Prop $msg 'payload') -is [ValueType] -and (Prop $msg 'payload') -isnot [bool]){$msg['payload']=$overrideValue}else{throw 'Temperature input is not a scalar; simulation needs manual review.'}}
 }catch{[void]$script:Uncertain.Add(([string](Prop $inject 'id')+': '+$_.Exception.Message));return}
 $queue=New-Object System.Collections.Queue
 foreach($output in @($inject.wires)){foreach($dest in @($output)){$queue.Enqueue(@{Id=[string]$dest;Msg=(Clone $msg);Trace=@([string](Prop $inject 'id'));Steps=0})}}
 $processed=0
 while($queue.Count -gt 0 -and $processed -lt 600){
  $item=$queue.Dequeue();$processed++;if($item.Steps -gt 100){[void]$script:Uncertain.Add('A loop or long route requires review.');continue}
  if(-not $script:Graph.ContainsKey($item.Id)){continue};$n=$script:Graph[$item.Id];$m=$item.Msg;$trace=@($item.Trace)+$item.Id;$outs=@();$stop=$false
  try{
   switch -CaseSensitive ([string](Prop $n 'type')){
    'change' {
     foreach($r in @(Prop $n 'rules' @())){
      if((Prop $r 'pt' 'msg') -cne 'msg'){throw 'Context (flow/global) is not evaluated offline.'}
      switch -CaseSensitive ([string](Prop $r 't')){
       'set' {SetPath $m ([string](Prop $r 'p')) (Typed (Prop $r 'to') ([string](Prop $r 'tot')) $m)}
       'delete' {DelPath $m ([string](Prop $r 'p'))}
       default {throw 'Only set/delete Change rules are evaluated offline.'}
      }
     };$outs=@($n.wires)
    }
    'switch' {
     if((Prop $n 'propertyType' 'msg') -cne 'msg'){throw 'Context-based Switch requires a live/manual check.'}
     $v=GetPath $m ([string](Prop $n 'property'));$matched=$false;$i=0;$w=@($n.wires)
     foreach($rule in @(Prop $n 'rules' @())){
      $op=[string](Prop $rule 't');$yes=$false
      if($op -ceq 'else'){$yes=-not $matched}else{
       $target=Typed (Prop $rule 'v') ([string](Prop $rule 'vt' 'str')) $m
       if($op -in @('lt','lte','gt','gte')){
        if($null -eq $v -or $null -eq $target -or $v -is [bool] -or $target -is [bool]){throw 'Missing/null/boolean Switch input requires manual review.'}
        if($v -is [string] -and $target -is [string]){$cmp=[string]::CompareOrdinal($v,$target);switch($op){'lt'{$yes=$cmp -lt 0};'lte'{$yes=$cmp -le 0};'gt'{$yes=$cmp -gt 0};'gte'{$yes=$cmp -ge 0}}}
        elseif((Num $v) -ne $null -and (Num $target) -ne $null){$a=Num $v;$b=Num $target;switch($op){'lt'{$yes=$a -lt $b};'lte'{$yes=$a -le $b};'gt'{$yes=$a -gt $b};'gte'{$yes=$a -ge $b}}}
        else{throw 'Non-numeric mixed Switch comparison requires manual review.'}
       }
       elseif($op -in @('eq','neq')){
        if($null -eq $v -or $null -eq $target){throw 'Missing/null Switch equality requires manual review.'}
        if($v -is [string] -and $target -is [string]){$yes=$v -ceq $target}
        elseif($v -is [bool] -or $target -is [bool]){throw 'Boolean/mixed Switch equality requires manual review.'}
        elseif((Num $v) -ne $null -and (Num $target) -ne $null){$yes=(Num $v) -eq (Num $target)}
        else{throw 'Object/mixed Switch equality requires manual review.'}
        if($op -ceq 'neq'){$yes=-not $yes}
       }
       else{throw ('Unsupported Switch comparison: '+$op)}
      }
      if($yes){$matched=$true;if($i -lt $w.Count){$outs+=,@($w[$i])};if((Prop $n 'checkall' 'true') -ceq 'false'){break}};$i++
     }
    }
    'http request' {
     $method=[string](Prop $n 'method' 'use');if($method -in @('use','')){$method=[string](Prop $m 'method' 'GET')}
     $url=[string](Prop $n 'url' '');if(-not $url){$url=[string](Prop $m 'url' '')};if($url -match '\{\{'){throw 'Templated URL requires manual review.'}
     $heads=Prop $m 'headers' @{};foreach($h in @(Prop $n 'headers' @())){if((Prop $h 'keyType' 'str') -cne 'str' -or (Prop $h 'valueType' 'str') -cne 'str'){throw 'Dynamic HTTP headers require manual review.'};if($heads -isnot [System.Collections.IDictionary]){$heads=NewMap};$heads[[string](Prop $h 'keyValue')]=Prop $h 'valueValue'}
     [void]$result.Add([pscustomobject]@{Inject=[string](Prop $inject 'id');Http=$item.Id;Method=$method;Url=$url;Payload=(Clone (Prop $m 'payload'));Headers=$heads;Trace=$trace;Return=[string](Prop $n 'ret')});$stop=$true
    }
    'debug' {$stop=$true}
    'comment' {$stop=$true}
    'link out' {foreach($dest in @(Prop $n 'links' @())){$outs+=,@([string]$dest)}}
    'link in' {$outs=@($n.wires)}
    'junction' {$outs=@($n.wires)}
    default {throw ('Node type not simulated: '+[string](Prop $n 'type'))}
   }
  }catch{[void]$script:Uncertain.Add(($item.Id+': '+$_.Exception.Message));$stop=$true}
  if(-not $stop){foreach($output in $outs){foreach($dest in @($output)){if($dest){$queue.Enqueue(@{Id=[string]$dest;Msg=(Clone $m);Trace=$trace;Steps=$item.Steps+1})}}}}
 }
 if($queue.Count){[void]$script:Uncertain.Add('Route limit reached; analysis is incomplete.')}
 return $result.ToArray()
}
function SameEndpoint([string]$a,[string]$b){$u=$null;$v=$null;if(-not [uri]::TryCreate($a,[UriKind]::Absolute,[ref]$u) -or -not [uri]::TryCreate($b,[UriKind]::Absolute,[ref]$v)){return $false};return $u.Scheme -eq $v.Scheme -and $u.Host -eq $v.Host -and $u.Port -eq $v.Port -and $u.AbsolutePath -ceq $v.AbsolutePath -and -not $u.Query}
function PayloadErrors($p,[string]$id){
 $e=@();if($p -isnot [System.Collections.IDictionary]){return 'payload не является объектом JSON'}
 $zone='server_room';if($id -ceq 'HUM-01'){$zone='work_area'}
 if((Prop $p 'zone') -cne $zone){$e+='zone'}
 $ts=Prop $p 'timestamp';$valid=$false
 if($ts -is [ValueType] -and $ts -isnot [bool]){$valid=(Num $ts) -ne $null -and [double]$ts -ge 0}
 elseif($ts -is [string]){$date=[datetimeoffset]::MinValue;$valid=[datetimeoffset]::TryParse($ts,[ref]$date)}
 if(-not $valid){$e+='timestamp отсутствует или имеет неверный тип'}
 if($id -ceq 'FAN-01'){
  if((Prop $p 'actuator_id') -cne $id){$e+='actuator_id'}
  if((Prop $p 'state') -cnotin @('ON','OFF')){$e+='state'}
  if((Prop $p 'mode') -cne 'auto'){$e+='mode: требуется auto для приёмника v3'}
 }else{
  if((Prop $p 'sensor_id') -cne $id){$e+='sensor_id'}
  $value=Prop $p 'value';if($value -isnot [ValueType] -or $value -is [bool] -or (Num $value) -eq $null){$e+='value должен быть числом, а не строкой'}
  if($id -ceq 'TEMP-01' -and (Prop $p 'unit') -cne 'C'){$e+='unit'}
  if($id -ceq 'HUM-01'){if((Prop $p 'unit') -cne '%'){$e+='unit'};if((Num $value) -ne $null -and ((Num $value) -lt 0 -or (Num $value) -gt 100)){$e+='humidity range'}}
 };return $e
}
function AnalyzeFlows($nodes,[string]$source){
 $script:Graph=@{};$tabs=@{};$all=@{};$dupes=@();$badWires=@()
 foreach($n in $nodes){$id=[string](Prop $n 'id');if(-not $id){continue};if($all.ContainsKey($id)){$dupes+=$id};$all[$id]=$n;if((Prop $n 'type') -ceq 'tab'){$tabs[$id]=$n}}
 foreach($n in $nodes){$id=[string](Prop $n 'id');$tab=Prop $tabs ([string](Prop $n 'z'));if((Prop $n 'type') -ceq 'tab' -or (Prop $n 'd' $false) -eq $true -or (Prop $n 'disabled' $false) -eq $true -or (Prop $tab 'disabled' $false) -eq $true){continue};if($id){$script:Graph[$id]=$n}}
 Check 'Node-RED' 'Источник анализа' 'PASS' $source
 if($dupes.Count){Check 'Node-RED' 'Уникальность id' 'FAIL' ('Повторяющийся id: '+($dupes -join ', '))}
 foreach($n in $script:Graph.Values){foreach($w in @($n.wires)){foreach($dest in @($w)){if($dest -and -not $all.ContainsKey([string]$dest)){$badWires+=([string](Prop $n 'id')+' -> '+[string]$dest)}}}}
 if($badWires.Count){Check 'Node-RED' 'Соединения' 'FAIL' ($badWires -join '; ')}else{Check 'Node-RED' 'Соединения' 'PASS' 'Включённые узлы не ссылаются проводами на отсутствующие узлы. Правильность маршрутов проверяется отдельно.'}
 $missingTabs=@($script:Graph.Values|Where-Object{(Prop $_ 'z') -and -not $tabs.ContainsKey([string](Prop $_ 'z'))}|ForEach-Object{[string](Prop $_ 'z')}|Select-Object -Unique)
 if($missingTabs.Count){Check 'Node-RED' 'Полнота экспорта' 'REVIEW' 'В экспорте отсутствует вкладка, на которую ссылаются узлы. Экспортируйте все потоки.'}
 $injects=@($script:Graph.Values|Where-Object{(Prop $_ 'type') -ceq 'inject'});$emissions=@()
 foreach($inj in $injects){$emissions+=@(EmitRoute $inj)}
 foreach($id in @('TEMP-01','HUM-01','FAN-01')){
  $found=@($emissions|Where-Object{(Prop $_.Payload 'sensor_id') -ceq $id -or (Prop $_.Payload 'actuator_id') -ceq $id})
  if(-not $found.Count){$st='FAIL';if($script:Uncertain.Count){$st='REVIEW'};Check 'Node-RED' ($id+' сформирован') $st 'Не удалось получить сообщение с этим идентификатором. Проверьте включение узлов, поля JSON и неподдерживаемые конструкции.';continue}
  $errors=@();foreach($r in $found){$errors+=@(PayloadErrors $r.Payload $id)|ForEach-Object{$r.Http+': '+$_};if($r.Method -cne 'POST'){$errors+=($r.Http+': метод HTTP должен быть POST')};$ct='';foreach($k in $r.Headers.Keys){if([string]$k -ieq 'Content-Type'){$ct=[string]$r.Headers[$k]}};if($ct -notmatch '^application/json(?:;|$)'){$errors+=($r.Http+': заголовок Content-Type должен быть application/json')}}
  if($errors.Count){Check 'Node-RED' ($id+' формат/метод/заголовок') 'FAIL' (($errors|Select-Object -Unique) -join '; ')}else{Check 'Node-RED' ($id+' формат/метод/заголовок') 'PASS' 'Узлы Inject/Change/Switch формируют сообщение требуемого формата и отправляют его методом POST с заголовком JSON.'}
  $endpoint='/api/readings';if($id -ceq 'FAN-01'){$endpoint='/api/actuators'}
  foreach($server in @('CtrlUrl','DbUrl')){
   $expected=$script:Cfg[$server]+$endpoint;$hits=@($found|Where-Object{SameEndpoint $_.Url $expected})
   if($hits.Count -eq 0){Check 'Node-RED' ($id+' -> '+$server) 'FAIL' ('Не найден маршрут к настроенному адресу '+$server+$endpoint+'; сравните IP, порт и путь в конфигурации проверки и узле HTTP request.')}
   else{
    $srcs=@($hits.Inject|Select-Object -Unique);$periodOk=$true
    foreach($src in $srcs){if((Num (Prop $script:Graph[$src] 'repeat')) -ne [double]$script:Cfg.ExpectedPeriod){$periodOk=$false}}
    if($srcs.Count -gt 1 -or $hits.Count -gt $srcs.Count){Check 'Node-RED' ($id+' -> '+$server) 'REVIEW' ('Несколько активных источников или маршрутов: '+($hits.Http -join ', ')+'. Проверьте дубли потоков и назначение дополнительных маршрутов.')}
    elseif(-not $periodOk){Check 'Node-RED' ($id+' период '+$server) 'FAIL' ('Источник отправляет сообщения с периодом, отличным от '+$script:Cfg.ExpectedPeriod+' с; узел '+($srcs -join ', '))}
    else{Check 'Node-RED' ($id+' -> '+$server) 'PASS' ('Периодический маршрут найден; Inject '+($srcs -join ', ')+', HTTP '+($hits.Http -join ', '))}
   }
  }
 }
 $tempSources=@($emissions|Where-Object{(Prop $_.Payload 'sensor_id') -ceq 'TEMP-01'}|ForEach-Object{$_.Inject}|Select-Object -Unique)
 if($tempSources.Count -eq 1){
  foreach($v in @(([double]$script:Cfg.Threshold-1),([double]$script:Cfg.Threshold),([double]$script:Cfg.Threshold+1))){
   $runs=@(EmitRoute $script:Graph[$tempSources[0]] $v $true);$fans=@($runs|Where-Object{(Prop $_.Payload 'actuator_id') -ceq 'FAN-01'})
   $expect='OFF';if(($script:Cfg.Comparison -eq 'ge' -and $v -ge [double]$script:Cfg.Threshold) -or ($script:Cfg.Comparison -eq 'gt' -and $v -gt [double]$script:Cfg.Threshold)){$expect='ON'}
   if(-not $fans.Count){Check 'Node-RED' ('Модель TEMP='+$v) 'REVIEW' 'Маршрут от температуры до FAN не подтверждён. Если используется независимый FAN или другая логика, проверьте вручную.'}
   elseif(@($fans|Where-Object{(Prop $_.Payload 'state') -cne $expect}).Count){Check 'Node-RED' ('Модель TEMP='+$v) 'FAIL' ('Ожидается '+$expect+' при указанном пороге и сравнении; проверьте Switch и выходы ON/OFF. HTTP узлы: '+($fans.Http -join ', '))}
   else{Check 'Node-RED' ('Модель TEMP='+$v) 'PASS' ('Проанализированная схема формирует '+$expect+'; это расчёт по схеме, сообщения в сеть не отправлялись.')}
  }
 }else{Check 'Node-RED' 'Модель порога' 'REVIEW' 'Не удалось однозначно определить один источник TEMP для расчёта порога.'}
 foreach($u in @($script:Uncertain|Select-Object -Unique)){$st='REVIEW';if($u -like '*Invalid JSON*'){$st='FAIL'};Check 'Node-RED' 'Неполный статический анализ' $st $u}
 Check 'Node-RED' 'Динамические Function и альтернативные конструкции' 'SKIP' 'Код JavaScript, JSONata, контекст и подпотоки не исполняются. PASS по схеме относится к поддерживаемым маршрутам.'
}
function Observe {
 $samples=New-Object System.Collections.Generic.List[object];$watch=[diagnostics.stopwatch]::StartNew();$next=0.0
 do{
  $m=Http ($script:Cfg.CtrlUrl+'/metrics');$rows=@{};if($script:DbAvailable){foreach($id in @('TEMP-01','HUM-01','FAN-01')){$rows[$id]=Row (Latest $id) $id}}
  [void]$samples.Add([pscustomobject]@{At=$watch.Elapsed.TotalSeconds;Metric=$m;Rows=$rows})
  $next+=[double]$script:Cfg.SampleInterval
  if($next -le [double]$script:Cfg.ObserveSeconds){$remain=$next-$watch.Elapsed.TotalSeconds;if($remain -gt 0){Start-Sleep -Milliseconds ([int]($remain*1000))}}
 }while($next -le [double]$script:Cfg.ObserveSeconds)
 foreach($id in @('TEMP-01','HUM-01')){
  $stamps=@();$ages=@();$values=@();$malformed=$false
  $metricName='office_temperature_celsius';if($id -ceq 'HUM-01'){$metricName='office_humidity_percent'}
  foreach($s in $samples){if($s.Metric.Code -ne 200){continue};$has=Metric $s.Metric.Text 'office_sensor_has_reading' 'sensor_id' $id;$ts=Metric $s.Metric.Text 'office_sensor_last_reading_timestamp_seconds' 'sensor_id' $id;$age=Metric $s.Metric.Text 'office_sensor_age_seconds' 'sensor_id' $id;$value=Metric $s.Metric.Text $metricName 'sensor_id' $id
   if($has -ne 1 -or $null -eq $ts -or $null -eq $age -or $null -eq $value){$malformed=$true;continue};$stamps+=,$ts;$ages+=,$age;$values+=,$value
  }
  $onlyAuth=@($samples|Where-Object{$_.Metric.Code -notin @(401,403)}).Count -eq 0
  if($onlyAuth){Check 'Живой CTRL' $id 'SKIP' 'Метрики требуют авторизации; показания не проверены.'}
  elseif($stamps.Count -lt 2 -or $malformed){Check 'Живой CTRL' $id 'FAIL' 'Метрики отсутствуют, неоднозначны или не являются числами; либо недостаточно успешных измерений.'}
  elseif($stamps[-1] -le $stamps[0]){Check 'Живой CTRL' $id 'FAIL' 'Время показания датчика не изменилось за период наблюдения. Проверьте периодическую отправку и timestamp.'}
  elseif(@($ages|Where-Object{$_ -gt [double]$script:Cfg.MaxSensorAge -or $_ -lt 0}).Count){Check 'Живой CTRL' $id 'FAIL' 'Данные обновляются, но возраст принятого показания превышал разрешённое значение.'}
  elseif($id -ceq 'HUM-01' -and @($values|Where-Object{$_ -lt 0 -or $_ -gt 100}).Count){Check 'Живой CTRL' $id 'FAIL' 'Влажность находится за пределами 0–100%.'}
  else{Check 'Живой CTRL' $id 'PASS' ('Время показаний обновляется; измерений: '+$stamps.Count+', последнее значение: '+$values[-1]+', возраст по часам приёмника: '+[math]::Round($ages[-1],1)+' с. Доставка каждого отдельного сообщения ровно через 5 с этой проверкой не подтверждается.')}
 }
 $last=$samples[$samples.Count-1];$fan=Metric $last.Metric.Text 'office_fan_on' 'actuator_id' 'FAN-01';$mode=Metric $last.Metric.Text 'office_control_mode_auto' 'actuator_id' 'FAN-01'
 if($last.Metric.Code -in @(401,403)){Check 'Живой CTRL' 'FAN метрика' 'SKIP' 'Метрики требуют авторизации.'}elseif($last.Metric.Code -eq 200 -and $null -ne $fan -and $fan -in @(0,1) -and $mode -eq 1){Check 'Живой CTRL' 'FAN метрика' 'PASS' ('Последнее состояние FAN='+$fan+', режим auto='+$mode+'. В метриках приёмника v3 нет возраста подтверждения FAN: наличие метрики само по себе не доказывает обновление.')}else{Check 'Живой CTRL' 'FAN метрика' 'FAIL' 'Нет числовой метрики FAN со значением 0 или 1 либо режим auto не равен 1.'}
 foreach($id in @('TEMP-01','HUM-01','FAN-01')){
  if(-not $script:DbAvailable){Check 'Живая DB' $id 'SKIP' 'Проверка /health базы не пройдена; записи не проверялись.';continue}
  $first=$null;$end=$null
  foreach($s in $samples){$row=Prop $s.Rows $id;if($null -eq $first -and $null -ne $row){$first=$row};if($null -ne $row){$end=$row}}
  if($script:LastDbCodes[$id] -in @(401,403)){Check 'Живая DB' $id 'SKIP' 'API истории требует авторизации.'}
  elseif($null -eq $first -or $null -eq $end){Check 'Живая DB' $id 'FAIL' 'Не получена запись этого устройства в массиве rows. Проверьте API базы, структуру таблиц и доступ.'}
  elseif((Num (Prop $end 'id')) -le (Num (Prop $first 'id')) -or (Num (Prop $end 'received_at')) -le (Num (Prop $first 'received_at'))){Check 'Живая DB' $id 'FAIL' 'id и received_at не увеличились: новые записи не подтверждены. Ответ /health не доказывает запись данных.'}
  else{Check 'Живая DB' $id 'PASS' ('Новые записи: id '+(Prop $first 'id')+' -> '+(Prop $end 'id')+', received_at увеличивается. Путь к файлу SQLite и структуру SQL эта проверка через HTTP не проверяет.')}
 }
}
function LiveFan {
 if($NonInteractive){Check 'FAN опыт' 'Интерактивный режим' 'SKIP' 'Этот режим требует участия преподавателя; уберите NonInteractive.';return}
 foreach($v in @(([double]$script:Cfg.Threshold-1),([double]$script:Cfg.Threshold),([double]$script:Cfg.Threshold+1),([double]$script:Cfg.Threshold-1))){
  $expected=0;if(($script:Cfg.Comparison -eq 'ge' -and $v -ge [double]$script:Cfg.Threshold) -or ($script:Cfg.Comparison -eq 'gt' -and $v -gt [double]$script:Cfg.Threshold)){$expected=1}
  $before=Http ($script:Cfg.CtrlUrl+'/metrics');$baseline=Metric $before.Text 'office_sensor_last_reading_timestamp_seconds' 'sensor_id' 'TEMP-01'
  [void](Read-Host ('Установите TEMP='+$v+' (number), Deploy. Затем Enter. Для прекращения Ctrl+C'))
  $w=[diagnostics.stopwatch]::StartNew();$stable=$null;$ok=$false
  while($w.Elapsed.TotalSeconds -lt [double]$script:Cfg.FanWaitSeconds){
   $m=Http ($script:Cfg.CtrlUrl+'/metrics');$temp=Metric $m.Text 'office_temperature_celsius' 'sensor_id' 'TEMP-01';$stamp=Metric $m.Text 'office_sensor_last_reading_timestamp_seconds' 'sensor_id' 'TEMP-01';$age=Metric $m.Text 'office_sensor_age_seconds' 'sensor_id' 'TEMP-01';$fan=Metric $m.Text 'office_fan_on' 'actuator_id' 'FAN-01';$mode=Metric $m.Text 'office_control_mode_auto' 'actuator_id' 'FAN-01'
   if($m.Code -eq 200 -and $null -ne $temp -and [math]::Abs($temp-$v) -lt .0001 -and $null -ne $stamp -and $stamp -gt $baseline -and $null -ne $age -and $age -le 20 -and $null -ne $fan -and $fan -eq $expected -and $mode -eq 1){if($null -eq $stable){$stable=$w.Elapsed.TotalSeconds};if($w.Elapsed.TotalSeconds-$stable -ge [double]$script:Cfg.ExpectedPeriod){$ok=$true;break}}else{$stable=$null}
   Start-Sleep -Seconds 2
  }
  if($ok){Check 'FAN опыт' ('TEMP='+$v) 'PASS' ('CTRL получил новую температуру; ожидаемое состояние FAN='+$expected+' в auto сохранялось не меньше одного периода. Проверяется телеметрия виртуального вентилятора.')}
  else{Check 'FAN опыт' ('TEMP='+$v) 'FAIL' ('Не подтверждены новая температура и устойчивое ожидаемое состояние FAN='+$expected+' в auto за отведённое время.')}
 }
}
function WriteReport {
 $dir=$OutputDirectory;if(-not $dir){$dir=Join-Path $PSScriptRoot 'Reports'};[void][IO.Directory]::CreateDirectory([IO.Path]::GetFullPath($dir));$tag=Get-Date -Format 'yyyyMMdd_HHmmss_fff';$prefix=Join-Path ([IO.Path]::GetFullPath($dir)) ('report_'+$tag)
 $rows=@($script:Checks.ToArray());$summary=@{};foreach($s in @('PASS','FAIL','REVIEW','SKIP')){$summary[$s]=@($rows|Where-Object{$_.Status -eq $s}).Count}
 $obj=[ordered]@{Student=$StudentName;Time=(Get-Date).ToString('o');Scope='Student baseline v3 / SQLite HTTP API. GET-only network inspection; local static simulation. Not a complete system certification.';AutomaticFailures=$summary.FAIL;Counts=$summary;Checks=$rows}
 $encoding=New-Object Text.UTF8Encoding($true);[IO.File]::WriteAllText($prefix+'.json',($obj|ConvertTo-Json -Depth 10),$encoding)
 $h={param($t)[System.Net.WebUtility]::HtmlEncode([string]$t)};$body='';foreach($r in $rows){$body+='<tr><td>'+(& $h $r.Area)+'</td><td>'+(& $h $r.Check)+'</td><td class="'+$r.Status+'">'+$r.Status+'</td><td>'+(& $h $r.Detail)+'</td></tr>'}
 $html='<!doctype html><html lang="ru"><meta charset="utf-8"><title>Проверка стенда</title><style>body{font:16px system-ui;margin:28px;color:#21313d}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd5db;padding:9px;text-align:left;vertical-align:top}th{background:#e8eff4}.PASS{color:#17683c}.FAIL{color:#b32626}.REVIEW,.SKIP{color:#815e00}p{max-width:1100px}</style><h1>Проверка студенческого стенда</h1><p>Студент: '+(& $h $StudentName)+' · '+(& $h (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz'))+'</p><p>PASS: '+$summary.PASS+' · FAIL: '+$summary.FAIL+' · REVIEW: '+$summary.REVIEW+' · SKIP: '+$summary.SKIP+'</p><p><b>Это не заключение «всё работает».</b> PASS относится только к названной проверке. REVIEW требует разбора, SKIP не проверено. Почту, правила Grafana, документы и поведение при отказах проверяет преподаватель отдельно. Файл потока не доказывает, что именно он запущен, если сравнение с API недоступно.</p><table><tr><th>Участок</th><th>Проверка</th><th>Результат</th><th>Наблюдение</th></tr>'+$body+'</table></html>'
 [IO.File]::WriteAllText($prefix+'.html',$html,$encoding);Write-Host ('Отчёт: '+$prefix+'.html');Write-Host ('JSON: '+$prefix+'.json')
}