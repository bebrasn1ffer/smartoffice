﻿#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ConfigPath,[string]$SecretsPath='', [string]$OutputDirectory='', [string]$RecoveryPath='')
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'GitAudit.ps1')
$ErrorActionPreference='Stop'
$script:Rows=[ordered]@{};$script:Events=New-Object System.Collections.Generic.List[object]
$script:Secrets=@{};$script:Audit=@{};$script:RuleInfo=@{};$script:PulseResults=@();$script:KnownRev='';$script:Checkpoint=$null;$script:Changed=$false;$script:Cancelled=$false
$script:DashSnapshots=@{};$script:RawRules=@();$script:GitAudit=$null;$script:CoreCycle=$null;$script:CoreComplete=$null;$script:RecoveryOk=$true
if(-not $OutputDirectory){$OutputDirectory=Join-Path $PSScriptRoot 'Reports'}
[void][IO.Directory]::CreateDirectory([IO.Path]::GetFullPath($OutputDirectory))
$script:CheckpointFile=Join-Path $OutputDirectory 'recovery.json'
$names=[ordered]@{'1.1'='Node-RED Compose и постоянный том';'1.2'='Два датчика и период 5 секунд';'2.1'='FAN ниже на границе и выше порога';'2.2'='CTRL принимает ON и OFF';'3.1'='Структура SQLite и SQL создания';'3.2'='Новые записи TEMP HUM FAN';'4.1'='Системные службы и сбор Prometheus';'4.2'='Панель Grafana и актуальность';'5.1'='Правило TEMP и маршрут Email';'5.2'='Правило HUM и маршрут Email';'5.3'='Реальное оповещение и письмо TEMP';'5.4'='Реальное оповещение и письмо HUM';'6.1'='Состав Git';'6.2'='README и передача';'7.1'='Инструкция просмотра';'7.2'='Инструкция при событии';'8.1'='Журнал работ';'8.2'='Журнал испытаний';'9.1'='Презентация';'9.2'='Выступление'}
foreach($k in $names.Keys){$script:Rows[$k]=[pscustomobject]@{Code=$k;Name=$names[$k];Max=5;AutoScore=$null;Status='НП';Reason='Требуется оценка жюри.'}}
function Event([string]$name,[string]$status,[string]$detail){[void]$script:Events.Add([pscustomobject]@{Time=(Get-Date).ToString('o');Check=$name;Status=$status;Detail=$detail});Write-Host ('['+$status+'] '+$name+': '+$detail)}
function Award([string]$code,$score,[string]$reason){$r=$script:Rows[$code];$r.AutoScore=$score;$r.Status='НП';if($null -ne $score){$r.Status='ЧАСТЬ';if($score -eq 5){$r.Status='ДА'}elseif($score -eq 0){$r.Status='НЕТ'}};$r.Reason=$reason;Event ($code+' '+$r.Name) $r.Status $reason}
function CancelCheck {if(Test-Path -LiteralPath (Join-Path $OutputDirectory 'cancel.flag')){$script:Cancelled=$true;throw 'CANCELLED'}}
function Pause([double]$seconds){$w=[diagnostics.stopwatch]::StartNew();while($w.Elapsed.TotalSeconds -lt $seconds){CancelCheck;Start-Sleep -Milliseconds 200}}
function Secret([string]$key){return [string](Prop $script:Secrets $key '')}
function Api([string]$base,[string]$path,[string]$method='GET',$body=$null,[string]$kind=''){
 $response=$null
 try{
  $req=[Net.HttpWebRequest]::Create($base.TrimEnd('/')+$path);$req.Method=$method;$req.Timeout=7000;$req.ReadWriteTimeout=7000;$req.Proxy=$null;$req.AllowAutoRedirect=$false;$req.Accept='application/json'
  if($kind -eq 'nr'){$req.Headers['Node-RED-API-Version']='v2';if($method -eq 'POST' -and $path -ceq '/flows'){$req.Headers['Node-RED-Deployment-Type']='nodes'};if((Secret 'NrToken')){$req.Headers['Authorization']='Bearer '+(Secret 'NrToken')}}
  if($kind -eq 'graf' -and (Secret 'GrafUser')){$raw=(Secret 'GrafUser')+':'+(Secret 'GrafPassword');$req.Headers['Authorization']='Basic '+[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($raw))}
  if($null -ne $body){$bytes=[Text.Encoding]::UTF8.GetBytes(($body|ConvertTo-Json -Depth 90 -Compress));$req.ContentType='application/json';$req.ContentLength=$bytes.Length;$w=$req.GetRequestStream();try{$w.Write($bytes,0,$bytes.Length)}finally{$w.Dispose()}}
  try{$response=$req.GetResponse()}catch [Net.WebException]{if($_.Exception.Response){$response=$_.Exception.Response}else{throw}}
  $stream=$response.GetResponseStream();$mem=New-Object IO.MemoryStream;$buf=New-Object byte[] 8192
  try{while(($n=$stream.Read($buf,0,$buf.Length)) -gt 0){$mem.Write($buf,0,$n);if($mem.Length -gt 5000000){throw 'RESPONSE_TOO_LARGE'}};$txt=[Text.Encoding]::UTF8.GetString($mem.ToArray())}finally{$stream.Dispose();$mem.Dispose()}
  $obj=$null;try{$obj=$txt|ConvertFrom-Json}catch{}
  return [pscustomobject]@{Code=[int]$response.StatusCode;Text=$txt;Json=$obj}
 }catch{return [pscustomobject]@{Code=0;Text='';Json=$null}}finally{if($response){$response.Close()}}
}
function NrGet {$r=Api $script:Cfg.NodeRedUrl '/flows' 'GET' $null 'nr';if($r.Code -ne 200 -or -not (Prop $r.Json 'rev')){throw 'NR_FLOWS_UNAVAILABLE'};[void](FlowArray $r.Json);return $r.Json}
function PythonCommand([string]$source,[string]$binary='python3'){$b64=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($source));return $binary+' -c "import base64;exec(base64.b64decode('+[char]39+$b64+[char]39+'))"'}
function Remote([string]$role,[string]$command){
 $hostName=([uri]$script:Cfg[$role+'Url']).Host;$port=[int](Prop $script:Config 'SshPort' 22);$fp=[string](Prop (Prop $script:Config 'KnownHosts') ($hostName+':'+$port) '')
 if(-not (Secret 'SshPassword') -or -not $fp){throw 'SSH_ACCESS_NOT_CONFIGURED'}
 $r=[StandAudit.Remote]::Run($hostName,$port,(Secret 'SshUser'),(Secret 'SshPassword'),$fp,$command)
 if($r.Code -ne 0){throw 'SSH_COMMAND_FAILED'};return $r.Output
}
function AuditHost([string]$role){try{$src=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'audit_host.py'));$a=(Remote $role (PythonCommand $src))|ConvertFrom-Json;$script:Audit[$role]=$a;Event ('SSH '+$role) 'ДА' 'Собраны сведения контейнеров и системных служб без изменения ВМ.'}catch{Event ('SSH '+$role) 'НП' 'Нет доступа, прав или подходящего окружения. Пункты, требующие SSH, автоматически не засчитываются.'}}
function PickContainer([string]$role,[string]$port,[string]$service=''){$a=Prop $script:Audit $role;$all=@(Prop $a 'containers' @());$hits=@($all|Where-Object{(Prop $_ 'ports').PSObject.Properties.Name -contains ($port+'/tcp')});if($hits.Count -ne 1 -and $service){$hits=@($all|Where-Object{(Prop $_ 'service') -ceq $service})};if($hits.Count -eq 1){return $hits[0]};return $null}
function DbAudit {
 $c=PickContainer 'Db' '8081' 'storage';if(-not $c){Event 'SQLite SSH' 'НП' 'Контейнер DB не определён однозначно.';return}
 try{$id=[string](Prop $c 'id');if($id -notmatch '^[a-f0-9]{12,64}$'){throw 'BAD_ID'};$src=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'audit_sqlite.py'));$sql=(Remote 'Db' ('docker exec '+$id+' '+(PythonCommand $src 'python')))|ConvertFrom-Json;$script:SqlAudit=$sql
  $expected=@{measurements=@('id','source','device_id','metric','zone','timestamp','received_at','value','unit','labels');actuator_events=@('id','source','device_id','zone','timestamp','received_at','state','mode')};$good=(Prop $sql 'integrity') -ceq 'ok'
  foreach($table in $expected.Keys){$cols=@(Prop (Prop (Prop $sql 'tables') $table) 'columns' @());if($cols.Count -ne $expected[$table].Count){$good=$false};foreach($name in $expected[$table]){if(@($cols|Where-Object{(Prop $_ 'name') -ceq $name}).Count -ne 1){$good=$false}}}
  $types=@{id='INTEGER';timestamp='INTEGER';received_at='INTEGER';value='REAL'};foreach($table in $expected.Keys){$cols=@(Prop (Prop (Prop $sql 'tables') $table) 'columns' @());foreach($col in $cols){$name=[string](Prop $col 'name');$type='TEXT';if($types.ContainsKey($name)){$type=$types[$name]};if(([string](Prop $col 'type')).ToUpperInvariant() -cne $type){$good=$false};if($name -ceq 'id'){if((Num (Prop $col 'pk')) -ne 1){$good=$false}}elseif((Num (Prop $col 'notnull')) -ne 1){$good=$false};if($name -ceq 'labels' -and (Prop $col 'dflt_value') -notin @([string]([char]39+'{}'+[char]39),'"{}"')){$good=$false}}}
  if($good){Award '3.1' 3 'Таблицы и целостность SQLite подтверждены чтением самой БД. SQL создания и объяснение назначения таблиц проверяет жюри.'}else{Award '3.1' 0 'Чтение файла SQLite выявило отсутствующую таблицу/поле или ошибку целостности.'}
 }catch{Event 'SQLite SSH' 'НП' 'Файл не прочитан: проверьте доступ, контейнер, DB_PATH и блокировку. Структура автоматически не оценена.'}
}
function SourceMap($nodes){
 AnalyzeFlows $nodes 'Развёрнутый поток Node-RED';$script:Sources=@{};$script:StaticGood=@{}
 foreach($id in @('TEMP-01','HUM-01','FAN-01')){$script:StaticGood[$id]=$true;$em=@();foreach($i in @($script:Graph.Values|Where-Object{(Prop $_ 'type') -ceq 'inject'})){$em+=@(EmitRoute $i)};$hits=@($em|Where-Object{(Prop $_.Payload 'sensor_id') -ceq $id -or (Prop $_.Payload 'actuator_id') -ceq $id});$ids=@($hits.Inject|Select-Object -Unique)
  if($ids.Count -eq 1){$script:Sources[$id]=$ids[0]}else{$script:StaticGood[$id]=$false}
  if(-not $hits.Count){$script:StaticGood[$id]=$false};foreach($x in $hits){if(@(PayloadErrors $x.Payload $id).Count -or $x.Method -cne 'POST'){$script:StaticGood[$id]=$false}}
 }
 foreach($id in @('TEMP-01','HUM-01')){if(-not $script:Sources[$id] -or (Num (Prop $script:Graph[$script:Sources[$id]] 'repeat')) -ne 5){$script:StaticGood[$id]=$false}}
 if($script:Uncertain.Count){Event 'Конструкции Node-RED' 'ПРОВЕРИТЬ' 'Есть конструкции, которые модель не исполняет. Баллы за неподтверждённые маршруты не выставляются.'}
}
function DbRows([string]$id,[int]$limit=100,[long]$stamp=0){$path='/api/history?device_id='+$id+'&limit='+$limit;if($stamp){$path+='&from='+$stamp+'&to='+$stamp};$r=Api $script:Cfg.DbUrl $path;if($r.Code -ne 200){return @()};return @(Prop $r.Json 'rows' @())}
function Metrics {return Api $script:Cfg.CtrlUrl '/metrics'}
function ObserveLive {
 Event 'Наблюдение' 'СТАРТ' '20 секунд: показания CTRL и появление новых записей DB.';$s=@();for($i=0;$i -le 4;$i++){CancelCheck;$m=Metrics;$rows=@{};foreach($id in @('TEMP-01','HUM-01','FAN-01')){$v=@(DbRows $id 1);if($v.Count -eq 1){$rows[$id]=$v[0]}};$s+=,[pscustomobject]@{Metric=$m;Rows=$rows};if($i -lt 4){Pause 5}}
 $script:LiveSensors=$true
 foreach($id in @('TEMP-01','HUM-01')){$st=@();foreach($x in $s){$v=Metric $x.Metric.Text 'office_sensor_last_reading_timestamp_seconds' 'sensor_id' $id;if($x.Metric.Code -eq 200 -and $null -ne $v -and (Metric $x.Metric.Text 'office_sensor_has_reading' 'sensor_id' $id) -eq 1){$st+=,$v}};if($st.Count -lt 3 -or $st[-1] -le $st[0]){$script:LiveSensors=$false;Event $id 'НП' 'Обновление показаний не подтверждено.'}else{Event $id 'ДА' 'Время показаний обновляется на CTRL.'}}
 $growth=$true;foreach($id in @('TEMP-01','HUM-01','FAN-01')){$first=Prop $s[0].Rows $id;$last=Prop $s[-1].Rows $id;if(-not $first -or -not $last -or (Num (Prop $last 'id')) -le (Num (Prop $first 'id')) -or (Num (Prop $last 'received_at')) -le (Num (Prop $first 'received_at'))){$growth=$false}}
 $script:DbGrowth=$growth
 if($script:LiveSensors -and $script:StaticGood['TEMP-01'] -and $script:StaticGood['HUM-01']){Award '1.2' 3 'Оба датчика обновляются; в развёрнутом потоке период 5 с и правильный формат. Испытание с новым назначенным значением ещё не выполнено.'}
 if($growth){Event 'Новые записи DB' 'ДА' 'id и received_at увеличились у TEMP, HUM и FAN. Назначенные контрольные значения проверяются в активном режиме.'}
}
function PromVector([string]$query){$r=Api $script:Cfg.PrometheusUrl ('/api/v1/query?query='+[uri]::EscapeDataString($query));if($r.Code -eq 200 -and (Prop $r.Json 'status') -ceq 'success'){return @(Prop (Prop $r.Json 'data') 'result' @())};return @()}
function Up {if(-not $script:TargetInstance){return $false};$xs=@(PromVector 'up{job="office-controller"}');$xs=@($xs|Where-Object{(Prop (Prop $_ 'metric') 'instance') -ceq $script:TargetInstance});return $xs.Count -eq 1 -and (Num (@(Prop $xs[0] 'value')[1])) -eq 1}
function PromCheck {
 $r=Api $script:Cfg.PrometheusUrl '/api/v1/targets?state=active';$xs=@(Prop (Prop $r.Json 'data') 'activeTargets' @()|Where-Object{(Prop (Prop $_ 'labels') 'job') -ceq 'office-controller' -and (SameEndpoint ([string](Prop $_ 'scrapeUrl')) ($script:Cfg.CtrlUrl+'/metrics'))})
 $script:TargetOk=$false
 if($r.Code -eq 200 -and $xs.Count -eq 1 -and (Prop $xs[0] 'health') -ceq 'up'){$script:TargetOk=$true;$script:TargetInstance=[string](Prop (Prop $xs[0] 'labels') 'instance');$period=(Prop $xs[0] 'scrapeInterval') -ceq '5s'}else{Event 'Prometheus target' 'НП' 'Цель UP для указанного CTRL не подтверждена.';return}
 $units=@(Prop (Prop $script:Audit 'Mon') 'services' @());$prom=@($units|Where-Object{(Prop $_ 'unit') -ceq 'prometheus.service' -and (Prop $_ 'active') -and (Prop $_ 'command') -match '(?:^|/)prometheus(?:\s|$)' -and (Prop $_ 'command') -notmatch 'docker|podman'});$graf=@($units|Where-Object{(Prop $_ 'unit') -in @('grafana-server.service','grafana.service') -and (Prop $_ 'active') -and (Prop $_ 'command') -match 'grafana' -and (Prop $_ 'command') -notmatch 'docker|podman'});$g=Api $script:Cfg.GrafanaUrl '/api/health'
 if($period -and $prom.Count -eq 1 -and $graf.Count -eq 1 -and $g.Code -eq 200 -and (Prop $g.Json 'database') -ceq 'ok'){Award '4.1' 5 'Подтверждены systemd службы Prometheus/Grafana, UP нужного CTRL и scrapeInterval=5s.'}else{Award '4.1' 3 'Нужная цель UP. Полностью не подтверждены systemd службы, период 5s или состояние Grafana.'}
}
function SamePromSource([string]$url){if(SameEndpoint $url $script:Cfg.PrometheusUrl){return $true};try{$a=[uri]$url;$b=[uri]$script:Cfg.PrometheusUrl;$g=[uri]$script:Cfg.GrafanaUrl;return $a.Host -in @('localhost','127.0.0.1','::1') -and $b.Host -eq $g.Host -and $a.Port -eq $b.Port -and $a.AbsolutePath -ceq $b.AbsolutePath}catch{return $false}}
function GrafGet([string]$path){return Api $script:Cfg.GrafanaUrl $path 'GET' $null 'graf'}
function Panels($panels){foreach($p in @($panels)){if(Prop $p 'targets'){Write-Output $p};if(Prop $p 'panels'){Panels (Prop $p 'panels')}}}
function DashboardCheck {
 try{$search=GrafGet '/api/search?type=dash-db';if($search.Code -ne 200){throw 'NO_ACCESS'};$required=@('office_temperature_celsius','office_humidity_percent','office_control_mode_auto','office_fan_on','office_sensor_age_seconds');$best=0
 foreach($d in @($search.Json)|Select-Object -First 15){CancelCheck;$r=GrafGet ('/api/dashboards/uid/'+[uri]::EscapeDataString([string](Prop $d 'uid')));if($r.Code -ne 200){continue};$script:DashSnapshots[[string](Prop $d 'uid')]=Prop $r.Json 'dashboard';$covered=@{}
  foreach($p in @(Panels (Prop (Prop $r.Json 'dashboard') 'panels' @()))){foreach($t in @(Prop $p 'targets' @())){if(Prop $t 'hide' $false){continue};$expr=[string](Prop $t 'expr');$uid=[string](Prop (Prop $t 'datasource' (Prop $p 'datasource')) 'uid');if(-not $uid -or $uid.Contains('$')){continue};$ds=GrafGet ('/api/datasources/uid/'+[uri]::EscapeDataString($uid));if($ds.Code -ne 200 -or -not (SamePromSource ([string](Prop $ds.Json 'url')))){continue};foreach($metric in $required){if($expr -notmatch ('\b'+[regex]::Escape($metric)+'\b')){continue};$q=GrafGet ('/api/datasources/proxy/uid/'+[uri]::EscapeDataString($uid)+'/api/v1/query?query='+[uri]::EscapeDataString($expr));$rr=@(Prop (Prop $q.Json 'data') 'result' @());if($q.Code -eq 200 -and (Prop $q.Json 'status') -ceq 'success' -and $rr.Count -gt 0 -and @($rr|Where-Object{(Num (@(Prop $_ 'value')[1])) -eq $null}).Count -eq 0){$covered[$metric]=$true}}}}
  if($covered.Count -gt $best){$best=$covered.Count};if($covered.Count -eq 5){Award '4.2' 3 'В одной панели найдены все 5 величин; их запросы выполнены через Grafana к нужному Prometheus. Визуальное отображение и изменение на экране подтверждает жюри.';$script:DashboardApiOk=$true;return}
 };Event 'Панель Grafana' 'НП' ('Не подтверждены все величины через API; найдено '+$best+' из 5. Переменные datasource и нестандартные запросы требуют ручной проверки.')
 }catch{Event 'Панель Grafana' 'НП' 'Нет доступа к API панели/источнику или версия API не поддержана. Это не автоматический ноль.'}
}
function AgeExpr([string]$expr,[string]$id){
 $m=[regex]::Match($expr.Trim(),'^office_sensor_age_seconds\s*\{(?<labels>[^}]*)\}\s*$');if(-not $m.Success){return $false};$labels=@{};$pattern='(?<k>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"(?<v>[^"\\]*)"';$remaining=[regex]::Replace($m.Groups['labels'].Value,$pattern,'');if($remaining -notmatch '^[,\s]*$'){return $false};foreach($x in [regex]::Matches($m.Groups['labels'].Value,$pattern)){if($labels.ContainsKey($x.Groups['k'].Value)){return $false};$labels[$x.Groups['k'].Value]=$x.Groups['v'].Value}
 return $labels['sensor_id'] -ceq $id -and ($null -eq $labels['job'] -or $labels['job'] -ceq 'office-controller') -and $m.Groups['labels'].Value -notmatch '=~|!~|!='
}
function RuleThreshold($rule,[string]$id){
 $data=@(Prop $rule 'data' @());$by=@{};foreach($x in $data){$by[[string](Prop $x 'refId')]=$x};$ref=[string](Prop $rule 'condition');$n=Prop $by $ref;if(-not $n){return $null};$model=Prop $n 'model';$type=[string](Prop $model 'type');$source=''
 if($type -in @('threshold','classic_conditions')){$cs=@(Prop $model 'conditions' @());if($cs.Count -ne 1 -or (Prop (Prop $cs[0] 'evaluator') 'type') -cne 'gt'){return $null};$params=@(Prop (Prop $cs[0] 'evaluator') 'params' @());if($params.Count -ne 1 -or (Num $params[0]) -ne 20){return $null};if($type -ceq 'threshold'){$source=[string](Prop $model 'expression')}else{$source=[string](@(Prop (Prop $cs[0] 'query') 'params' @())[0]);if((Prop (Prop $cs[0] 'reducer') 'type') -cne 'last'){return $null}}}
 elseif($type -ceq 'math'){$m=[regex]::Match([string](Prop $model 'expression'),'^\s*\$(?<ref>[A-Za-z0-9_]+)\s*>\s*20(?:\.0+)?\s*$');if(-not $m.Success){return $null};$source=$m.Groups['ref'].Value}else{return $null}
 $x=Prop $by $source;if(-not $x){return $null};$model=Prop $x 'model'
 if((Prop $model 'type') -ceq 'reduce'){if((Prop $model 'reducer') -cne 'last'){return $null};$x=Prop $by ([string](Prop $model 'expression'));$model=Prop $x 'model'}
 if(-not (AgeExpr ([string](Prop $model 'expr')) $id)){return $null};return [pscustomobject]@{Uid=[string](Prop $x 'datasourceUid');Expr=[string](Prop $model 'expr')}
}
function MatchRoute($route,$labels){
 foreach($m in @(Prop $route 'object_matchers' @())){if(@($m).Count -ne 3){return $false};$v=[string](Prop $labels ([string]$m[0]) '');switch -CaseSensitive ([string]$m[1]){'=' {if($v -cne [string]$m[2]){return $false}};'!=' {if($v -ceq [string]$m[2]){return $false}};'=~' {if($v -cnotmatch ('^(?:'+[string]$m[2]+')$')){return $false}};'!~' {if($v -cmatch ('^(?:'+[string]$m[2]+')$')){return $false}};default{return $false}}}
 if(@(Prop $route 'matchers' @()).Count -gt 0 -or (Prop $route 'match') -or (Prop $route 'match_re')){throw 'UNSUPPORTED_ROUTE'};return $true
}
function RouteReceivers($route,$labels,[string]$inherited=''){
 if(-not (MatchRoute $route $labels)){return @()};if(@(Prop $route 'mute_time_intervals' @()).Count -or @(Prop $route 'active_time_intervals' @()).Count){throw 'SCHEDULED_ROUTE'};$receiver=[string](Prop $route 'receiver' $inherited);$found=@();foreach($child in @(Prop $route 'routes' @())){if(MatchRoute $child $labels){$sub=@(RouteReceivers $child $labels $receiver);$found+=@($sub);if(-not (Prop $child 'continue' $false)){break}}};if(-not $found.Count -and $receiver){$found+=,$receiver};return $found
}
function AlertConfig {
 $rules=GrafGet '/api/v1/provisioning/alert-rules';$contacts=GrafGet '/api/v1/provisioning/contact-points';$policies=GrafGet '/api/v1/provisioning/policies'
 if($rules.Code -ne 200 -or $contacts.Code -ne 200 -or $policies.Code -ne 200){Event 'Правила Grafana' 'НП' 'Для проверки нужен доступ к API правил, контактов и политик. 401/403/404 не превращается в ноль.';return}
 $script:RawRules=@($rules.Json);foreach($id in @('TEMP-01','HUM-01')){$code='5.1';if($id -ceq 'HUM-01'){$code='5.2'};$candidates=@();foreach($rule in @($rules.Json)){if(RuleThreshold $rule $id){$candidates+=,$rule}}
  if($candidates.Count -ne 1){Event ('Правило '+$id) 'НП' 'Не найдено одно однозначно интерпретируемое правило возраста >20 с. Альтернативный PromQL/Math разберите вручную.';continue}
  $rule=$candidates[0];$spec=RuleThreshold $rule $id;$uid=$spec.Uid;$ds=GrafGet ('/api/datasources/uid/'+[uri]::EscapeDataString($uid));$group=GrafGet ('/api/v1/provisioning/folder/'+[uri]::EscapeDataString([string](Prop $rule 'folderUID'))+'/rule-groups/'+[uri]::EscapeDataString([string](Prop $rule 'ruleGroup')))
  $good=$ds.Code -eq 200 -and (SamePromSource ([string](Prop $ds.Json 'url'))) -and $group.Code -eq 200 -and (Num (Prop $group.Json 'interval')) -eq 10 -and (Prop $rule 'for') -in @('0s','0m','0') -and -not (Prop $rule 'isPaused' $false)
  $labels=AsMap (Prop $rule 'labels' ([pscustomobject]@{}));$labels['alertname']=[string](Prop $rule 'title');$samples=@(PromVector $spec.Expr);if($samples.Count -ne 1 -or (Prop (Prop $samples[0] 'metric') 'instance') -cne $script:TargetInstance){$good=$false};$folder=GrafGet ('/api/folders/'+[uri]::EscapeDataString([string](Prop $rule 'folderUID')));if($folder.Code -eq 200){$labels['grafana_folder']=[string](Prop $folder.Json 'title')};if((Prop $rule 'notification_settings') -or (Prop $rule 'notificationSettings')){$good=$false}
  try{if(@(Prop $policies.Json 'routes' @()).Count -gt 0){$good=$false};$receivers=@(RouteReceivers $policies.Json $labels);$email=@($contacts.Json|Where-Object{(Prop $_ 'type') -ceq 'email' -and ([string](Prop (Prop $_ 'settings') 'addresses')).Trim() -and $receivers -ccontains [string](Prop $_ 'name')});if(-not $email.Count){$good=$false}}catch{$good=$false}
  $script:RuleInfo[$id]=[pscustomobject]@{Uid=[string](Prop $rule 'uid');Title=[string](Prop $rule 'title');ConfigOk=$good}
  if($good){Award $code 5 'Подтверждены конкретный датчик, возраст >20, last/threshold, оценка 10 с, Pending 0, нужный Prometheus и маршрут к Email с непустым адресом. Доставка письма этим не доказана.'}else{Award $code 3 'Правило возраста нужного датчика найдено; период/Pending, источник, пауза или маршрут Email полностью не подтверждены.'}
 }
}
function AlertState([string]$id){$known=Prop $script:RuleInfo $id;if(-not $known){return $null};$r=GrafGet '/api/prometheus/grafana/api/v1/rules';if($r.Code -ne 200){return $null};$found=@();foreach($g in @(Prop (Prop $r.Json 'data') 'groups' @())){foreach($rule in @(Prop $g 'rules' @())){if((Prop $rule 'name') -ceq (Prop $known 'Title')){$found+=,$rule}}};if($found.Count -ne 1 -or (Prop $found[0] 'health' 'ok') -cne 'ok'){return $null};return [string](Prop $found[0] 'state')}
function SaveCheckpoint {$script:Checkpoint.ExpectedRev=$script:KnownRev;[IO.File]::WriteAllText($script:CheckpointFile,($script:Checkpoint|ConvertTo-Json -Depth 90),[Text.UTF8Encoding]::new($true))}
function SetTimers([string[]]$paused){
 CancelCheck;$hadChanges=$script:Changed;$flow=NrGet;if(([string](Prop $flow 'rev')) -cne $script:KnownRev){throw 'NR_CONCURRENT_CHANGE'}
 foreach($id in $script:Checkpoint.Original.Keys){$n=@(Prop $flow 'flows'|Where-Object{(Prop $_ 'id') -ceq $id});if($n.Count -ne 1 -or (Prop $n[0] 'type') -cne 'inject'){throw 'NR_NODE_CHANGED'};$orig=$script:Checkpoint.Original[$id]
  if($paused -ccontains $id){$n[0].repeat='';$n[0].once=$false}else{$n[0].repeat=$orig.repeat;$n[0].once=$orig.once}
 }
 $script:Changed=$true;$script:Checkpoint.Touched=$true;$script:Checkpoint.Restored=$false;SaveCheckpoint
 $r=Api $script:Cfg.NodeRedUrl '/flows' 'POST' $flow 'nr';if($r.Code -in @(401,403,409) -and -not $hadChanges){$script:Checkpoint.Touched=$false;$script:Checkpoint.Restored=$true;$script:Changed=$false;SaveCheckpoint};if($r.Code -ne 200 -or -not (Prop $r.Json 'rev')){throw 'NR_DEPLOY_FAILED'};$script:KnownRev=[string](Prop $r.Json 'rev');SaveCheckpoint;Pause 1
}
function RestoreTimers {
 if(-not $script:Checkpoint -or $script:Checkpoint.Restored){return $true}
 if((Has $script:Checkpoint 'Touched') -and -not (Prop $script:Checkpoint 'Touched')){$script:Checkpoint.Restored=$true;SaveCheckpoint;return $true}
 try{$flow=NrGet;foreach($id in $script:Checkpoint.Original.Keys){$n=@(Prop $flow 'flows'|Where-Object{(Prop $_ 'id') -ceq $id});if($n.Count -ne 1 -or (Prop $n[0] 'type') -cne 'inject'){throw 'MISSING_INJECT'};$orig=$script:Checkpoint.Original[$id];$now=[string](Prop $n[0] 'repeat');if($now -cne '' -and $now -cne [string]$orig.repeat){throw 'EXTERNAL_TIMER_CHANGE'};$n[0].repeat=$orig.repeat;$n[0].once=$orig.once}
  $r=Api $script:Cfg.NodeRedUrl '/flows' 'POST' $flow 'nr';if($r.Code -ne 200){throw 'RESTORE_FAILED'};$script:KnownRev=[string](Prop $r.Json 'rev');$script:Checkpoint.Restored=$true;SaveCheckpoint;$script:Changed=$false;Event 'Восстановление таймеров' 'ДА' 'Исходные repeat и once возвращены; остальные узлы из текущей ревизии сохранены.';return $true
 }catch{$script:RecoveryOk=$false;Event 'ВОССТАНОВЛЕНИЕ' 'НУЖНО ВМЕШАТЕЛЬСТВО' ('Не удалось безопасно восстановить таймеры. Не продолжайте защиту без проверки Node-RED. Файл: '+$script:CheckpointFile);return $false}
}
function Pulse([string]$device,[double]$value){
 CancelCheck;$id=[string]$script:Sources[$device];$stamp=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();$body=@{__user_inject_props__=@(@{p='payload';v=$value.ToString($script:Inv);vt='num'},@{p='timestamp';v=[string]$stamp;vt='num'})};$r=Api $script:Cfg.NodeRedUrl ('/inject/'+[uri]::EscapeDataString($id)) 'POST' $body 'nr';if($r.Code -ne 200){throw 'NR_INJECT_FAILED'}
 $fan='OFF';if(($script:Cfg.Comparison -eq 'ge' -and $value -ge $script:Cfg.Threshold) -or ($script:Cfg.Comparison -eq 'gt' -and $value -gt $script:Cfg.Threshold)){$fan='ON'}
 $ok=$false;$db=$false;$fanOk=$false;$watch=[diagnostics.stopwatch]::StartNew()
 do{CancelCheck;$m=Metrics;$metric='office_temperature_celsius';if($device -ceq 'HUM-01'){$metric='office_humidity_percent'};$v=Metric $m.Text $metric 'sensor_id' $device;$ts=Metric $m.Text 'office_sensor_last_reading_timestamp_seconds' 'sensor_id' $device
  if($m.Code -eq 200 -and $null -ne $v -and [math]::Abs($v-$value) -lt .00001 -and $null -ne $ts -and [math]::Abs($ts-($stamp/1000.0)) -lt .002){$ok=$true}
  $rows=@(DbRows $device 100 $stamp);$db=@($rows|Where-Object{(Num (Prop $_ 'timestamp')) -eq $stamp -and (Num (Prop $_ 'value')) -eq $value}).Count -gt 0
  if($device -ceq 'TEMP-01'){$f=Metric $m.Text 'office_fan_on' 'actuator_id' 'FAN-01';$frows=@(DbRows 'FAN-01' 100 $stamp);$fanOk=$null -ne $f -and $f -eq [int]($fan -ceq 'ON') -and (Metric $m.Text 'office_control_mode_auto' 'actuator_id' 'FAN-01') -eq 1 -and @($frows|Where-Object{(Num (Prop $_ 'timestamp')) -eq $stamp -and (Prop $_ 'state') -ceq $fan}).Count -gt 0}else{$fanOk=$true}
  if($ok -and $db -and $fanOk){break};Pause .4
 }while($watch.Elapsed.TotalSeconds -lt 12)
 $result=[pscustomobject]@{Device=$device;Value=$value;Timestamp=$stamp;Ctrl=$ok;Db=$db;Fan=$fanOk;ExpectedFan=$fan};$script:PulseResults+=,$result;Event ('Опыт '+$device+'='+$value) 'РЕЗУЛЬТАТ' ('CTRL='+$ok+'; DB='+$db+'; FAN='+$fanOk);return $result
}
function ReceiverLogs {
 $c=PickContainer 'Ctrl' '8080' 'receiver';if(-not $c){return @()};$id=[string](Prop $c 'id');if($id -notmatch '^[a-f0-9]{12,64}$'){return @()}
 try{$text=Remote 'Ctrl' ('docker logs --tail 500 '+$id+' 2>&1');$out=@();foreach($line in $text -split "`n"){try{$o=$line|ConvertFrom-Json;if(Prop $o 'received_at'){$out+=,$o}}catch{}};return $out}catch{return @()}
}
function WaitNormal([string]$id,[double]$seconds=50){$w=[diagnostics.stopwatch]::StartNew();do{CancelCheck;$m=Metrics;$age=Metric $m.Text 'office_sensor_age_seconds' 'sensor_id' $id;$state=AlertState $id;if($null -ne $age -and $age -lt 10 -and $state -ceq 'inactive'){return $true};Pause 2}while($w.Elapsed.TotalSeconds -lt $seconds);return $false}
function AlertTrial([string]$device){
 if(-not (Prop $script:RuleInfo $device) -or -not (Up)){Event ('Опыт алерта '+$device) 'НП' 'Правило или цель не подтверждены.';return}
 $initial=AlertState $device;if($initial -cne 'inactive'){Event ('Опыт алерта '+$device) 'НП' 'Перед опытом правило должно быть Normal; поддерживаемый API не подтвердил inactive.';return}
 SetTimers @([string]$script:Sources[$device]);$other='HUM-01';$code='5.3';if($device -ceq 'HUM-01'){$other='TEMP-01';$code='5.4'};$start=Metrics;$otherBefore=Metric $start.Text 'office_sensor_last_reading_timestamp_seconds' 'sensor_id' $other;$fired=$false;$healthy=$true;$w=[diagnostics.stopwatch]::StartNew()
 do{CancelCheck;$m=Metrics;$age=Metric $m.Text 'office_sensor_age_seconds' 'sensor_id' $device;$otherAge=Metric $m.Text 'office_sensor_age_seconds' 'sensor_id' $other;$otherStamp=Metric $m.Text 'office_sensor_last_reading_timestamp_seconds' 'sensor_id' $other;$state=AlertState $device;$otherState=AlertState $other
  if($m.Code -ne 200 -or -not (Up) -or $null -eq $otherAge -or $otherAge -gt 12){$healthy=$false;break}
  if($null -ne $age -and $age -gt 20 -and $state -ceq 'firing' -and $otherState -ceq 'inactive' -and $otherStamp -gt $otherBefore){$fired=$true;break};Pause 3
 }while($w.Elapsed.TotalSeconds -lt 90)
 SetTimers @();$normal=WaitNormal $device
 if($fired -and $healthy -and $normal){Award $code 3 'При остановке только этого датчика подтверждены возраст >20, Alerting, UP и работа другого датчика; после восстановления Normal. Реальное письмо должен предъявить студент — программа почту не читает.'}elseif(-not $healthy){Event ('Опыт '+$device) 'НП' 'Нарушены условия опыта: CTRL/UP или другой датчик недоступны. Повторите вручную.'}else{Event ('Опыт '+$device) 'НП' 'За отведённое время поддерживаемый API не подтвердил полный цикл Alerting → Normal. Письмо и причину проверяет жюри.'}
}
function ActiveTests {
 if(-not (Prop $script:Config 'ActiveTests' $false)){Event 'Активные испытания' 'НП' 'Не разрешены оператором. Датчики не останавливались, контрольные сообщения не посылались.';return}
 if(-not $script:LiveFlow -or -not $script:Sources['TEMP-01'] -or -not $script:Sources['HUM-01'] -or $script:Sources['TEMP-01'] -ceq $script:Sources['HUM-01'] -or -not $script:StaticGood['TEMP-01'] -or -not $script:StaticGood['HUM-01'] -or $script:Uncertain.Count){Event 'Активные испытания' 'НП' 'Нет однозначных поддерживаемых маршрутов TEMP/HUM. Потоки не менялись.';return}
 $current=NrGet;$script:KnownRev=[string](Prop $current 'rev');$original=@{};foreach($id in @($script:Sources['TEMP-01'],$script:Sources['HUM-01'])){$n=@(Prop $current 'flows'|Where-Object{(Prop $_ 'id') -ceq $id})[0];$original[$id]=@{repeat=[string](Prop $n 'repeat' '');once=[bool](Prop $n 'once' $false)}}
 [IO.File]::WriteAllText((Join-Path $OutputDirectory 'flows_before_tests.json'),($current|ConvertTo-Json -Depth 90),[Text.UTF8Encoding]::new($true));$script:Checkpoint=@{ProfileName=[string](Prop $script:Config 'ProfileName' '');NodeRedUrl=$script:Cfg.NodeRedUrl;Original=$original;ExpectedRev=$script:KnownRev;Touched=$false;Restored=$false};SaveCheckpoint
 try{
  SetTimers @([string]$script:Sources['TEMP-01']);$results=@();foreach($v in @(([double]$script:Cfg.Threshold-1),[double]$script:Cfg.Threshold,([double]$script:Cfg.Threshold+1),([double]$script:Cfg.Threshold-1))){$results+=,(Pulse 'TEMP-01' $v)}
  SetTimers @([string]$script:Sources['TEMP-01'],[string]$script:Sources['HUM-01']);$h=Pulse 'HUM-01' 57.374;$allCtrl=@($results|Where-Object{-not $_.Ctrl}).Count -eq 0;$allDb=@($results|Where-Object{-not $_.Db}).Count -eq 0;$allFan=@($results|Where-Object{-not $_.Fan}).Count -eq 0
  if($allCtrl -and $allDb -and $allFan){Award '2.1' 5 'Все четыре контрольных температуры прошли из Inject в CTRL/SQLite; состояния FAN правильны по обе стороны и на границе порога.'}
  if($allCtrl -and $h.Ctrl -and $script:LiveSensors){Award '1.2' 5 'Оба датчика обновляются, формат и период в развёрнутом потоке верны; новые контрольные значения и метки времени приняты CTRL.'}
  if($allDb -and $h.Db -and $allFan -and $script:DbGrowth){Award '3.2' 5 'До опыта росли записи всех устройств; контрольные значения и timestamps TEMP/HUM/FAN найдены через историю DB.';$script:CoreCycle=$true}
  $logs=@(ReceiverLogs);$allLogs=$true;foreach($x in $results){if(@($logs|Where-Object{(Prop $_ 'actuator_id') -ceq 'FAN-01' -and (Num (Prop $_ 'timestamp')) -eq $x.Timestamp -and (Prop $_ 'state') -ceq $x.ExpectedFan -and (Prop $_ 'mode') -ceq 'auto'}).Count -eq 0){$allLogs=$false}}
  if($allCtrl -and $allFan -and $allLogs){Award '2.2' 5 'В журнале CTRL найдены принятые ON и OFF с точными метками контрольных сообщений; метрики и DB согласуются.'}elseif($allCtrl -and $allFan){Award '2.2' 3 'В опытах состояния метрик CTRL и события DB согласуются. Нет точного подтверждения обоих состояний в журнале CTRL — нужен SSH или показ журнала.'}
  SetTimers @();if((Prop $script:Config 'AlertTests' $false) -and $script:RuleInfo.Count -gt 0){Pause 7;[void](WaitNormal 'TEMP-01' 25);[void](WaitNormal 'HUM-01' 25);AlertTrial 'TEMP-01';AlertTrial 'HUM-01'}
 }finally{[void](RestoreTimers)}
}
function WriteResult {
 $rows=@($script:Rows.Values);$points=0;$assigned=0;foreach($r in $rows){if($null -ne $r.AutoScore){$points+=[int]$r.AutoScore;$assigned++}}
 $display=[string](Prop $script:Config 'StudentName' '');if(-not $display){$display=[string](Prop $script:Config 'ProfileName' '')};$result=[ordered]@{Version=2;Student=$display;ProfileName=[string](Prop $script:Config 'ProfileName' '');Time=(Get-Date).ToString('o');AutomaticPoints=$points;AutomaticCeiling=60;Git=$script:GitAudit;EvaluatedCriteria=$assigned;ProjectMaximum=100;FinalGrade=$null;FlowAnalysis=@($script:Checks.ToArray());Scope='Автоматические рекомендации; итог подтверждает жюри. Не проверены настоящие письма, качество материалов и ответы.';Cancelled=$script:Cancelled;RestorationConfirmed=$script:RecoveryOk;RecoveryFile=$script:CheckpointFile;CoreCycle=$script:CoreCycle;CoreComplete=$script:CoreComplete;Criteria=$rows;Tests=@($script:Events.ToArray());Pulses=$script:PulseResults}
 $enc=[Text.UTF8Encoding]::new($true);[IO.File]::WriteAllText((Join-Path $OutputDirectory 'assessment.json'),($result|ConvertTo-Json -Depth 30),$enc)
 try{$docs=Join-Path $PSScriptRoot 'lib/StandAudit.Documents.dll';[void][Reflection.Assembly]::LoadFrom($docs);$parts=[StandAudit.Documents]::Parts((AsMap $result));[StandAudit.Documents]::WriteParts($parts,(Join-Path $OutputDirectory 'report.docx'));$result.DocxParts=$parts;[IO.File]::WriteAllText((Join-Path $OutputDirectory 'assessment.json'),($result|ConvertTo-Json -Depth 40),$enc)}catch{Write-Host 'Word-лист не создан; исходный JSON и HTML сохранены. Проверьте .NET Framework 4.8.'}
 $template=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'report.html'));$payload=($result|ConvertTo-Json -Depth 30 -Compress).Replace('<','\u003c').Replace('>','\u003e').Replace('&','\u0026');$html=$template.Replace('__REPORT_JSON__',$payload).Replace('__DOCX_JS__',[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'docx_browser.js')));[IO.File]::WriteAllText((Join-Path $OutputDirectory 'report.html'),$html,$enc);Write-Host ('ОТЧЁТ: '+(Join-Path $OutputDirectory 'report.html'))
}
try{
 $script:Config=Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8|ConvertFrom-Json;foreach($p in $script:Config.PSObject.Properties){if($script:Cfg.ContainsKey($p.Name)){$script:Cfg[$p.Name]=$p.Value}}
 foreach($k in @('NodeRedUrl','CtrlUrl','DbUrl','PrometheusUrl','GrafanaUrl')){$script:Cfg[$k]=ValidBase ([string]$script:Cfg[$k])};$script:Cfg.Threshold=Num $script:Cfg.Threshold;if($null -eq $script:Cfg.Threshold -or $script:Cfg.Comparison -notin @('ge','gt')){throw 'INVALID_THRESHOLD'}
 if($SecretsPath){Add-Type -AssemblyName System.Security;$blob=[IO.File]::ReadAllBytes($SecretsPath);$clear=[Security.Cryptography.ProtectedData]::Unprotect($blob,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);try{$script:Secrets=AsMap ([Text.Encoding]::UTF8.GetString($clear)|ConvertFrom-Json)}finally{[Array]::Clear($clear,0,$clear.Length)}}
 $dll=Join-Path $PSScriptRoot 'lib/StandAudit.Remote.dll';if(Test-Path -LiteralPath $dll){[void][Reflection.Assembly]::LoadFrom($dll)}
 if($RecoveryPath){$recovery=Get-Content -LiteralPath $RecoveryPath -Raw -Encoding UTF8|ConvertFrom-Json;if((Prop $recovery 'NodeRedUrl') -cne $script:Cfg.NodeRedUrl){throw 'RECOVERY_ADDRESS_MISMATCH'};$script:Checkpoint=AsMap $recovery;$script:CheckpointFile=$RecoveryPath;[void](RestoreTimers)}
 else{
  if(Prop $script:Config 'Offline' $false){$file=[string](Prop $script:Config 'FlowsPath' '');if(-not $file -or -not (Test-Path -LiteralPath $file)){throw 'OFFLINE_FILE_MISSING'};SourceMap (FlowArray (Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json));Event 'Offline' 'НП' 'Выполнен анализ экспорта без сетевых запросов. Баллы за работу стенда не начислялись.';GitCheck}
  else{
  foreach($role in @('NodeRed','Ctrl','Db','Mon')){CancelCheck;if($role -eq 'Mon'){$script:Cfg['MonUrl']=$script:Cfg.PrometheusUrl};if(Secret 'SshPassword'){AuditHost $role}}
  try{$live=NrGet;$script:LiveFlow=$live;$nodes=FlowArray $live;SourceMap $nodes}catch{$script:LiveFlow=$null;$file=[string](Prop $script:Config 'FlowsPath' '');if($file -and (Test-Path -LiteralPath $file)){SourceMap (FlowArray (Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json));Event 'Node-RED экспорт' 'НП' 'Анализируется локальный файл; активные тесты и полные баллы без развёрнутого потока не выполняются.'}else{Event 'Node-RED' 'НП' 'Нет доступа к GET /flows и нет корректного экспорта.'}}
  if(-not $script:Sources){$script:Sources=@{};$script:StaticGood=@{}}
  $c=PickContainer 'NodeRed' '1880' 'node-red';$editor=Api $script:Cfg.NodeRedUrl '/';$mounted=@(Prop $c 'mounts' @()|Where-Object{(Prop $_ 'Destination') -ceq '/data' -and (Prop $_ 'Type') -in @('bind','volume') -and (Prop $_ 'Source')})
  if($script:LiveFlow -and $editor.Code -eq 200 -and $c -and (Prop $c 'compose_exists') -and $mounted.Count -eq 1){Award '1.1' 5 'Работающий Node-RED доступен; SSH подтверждает Compose и bind/volume на /data.'}elseif($script:LiveFlow -and $editor.Code -eq 200){Award '1.1' 3 'Редактор/API доступны. Compose или постоянный том не подтверждены через SSH.'}
  DbAudit;PromCheck;ObserveLive;DashboardCheck;AlertConfig;GitCheck;ActiveTests
  }
 }
}catch{if($_.Exception.Message -ceq 'CANCELLED'){Event 'Проверка' 'ОТМЕНА' 'Оператор запросил остановку; выполняется восстановление.'}else{Event 'Диагностика' 'НП' ('Тип ошибки: '+$_.Exception.GetType().Name+'; строка '+$_.InvocationInfo.ScriptLineNumber);if($_.Exception.Message -match '^[A-Z][A-Z0-9_]{3,80}$'){Event 'Код операции' 'НП' $_.Exception.Message};Event 'Проверка' 'НП' 'Операция не завершена: нет доступа, неподдерживаемая конструкция или изменение потока во время опыта. Подробности — в предыдущих проверках; баллы за непроверенное не начисляются.'}}
finally{
 if($script:Checkpoint -and -not $script:Checkpoint.Restored){[void](RestoreTimers)}
 if($SecretsPath -and (Test-Path -LiteralPath $SecretsPath)){Remove-Item -LiteralPath $SecretsPath -Force}
 $script:Secrets=@{};WriteResult
}
