import sqlite3,os,json
from pathlib import Path
p=Path(os.environ.get('DB_PATH','/data/telemetry.sqlite3'))
c=sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True,timeout=8);c.row_factory=sqlite3.Row
out={'integrity':c.execute('PRAGMA quick_check').fetchone()[0],'tables':{}}
for name in ['measurements','actuator_events']:
 out['tables'][name]={'columns':[dict(r)for r in c.execute('PRAGMA table_info('+name+')')],'rows':[dict(r)for r in c.execute('SELECT * FROM '+name+' ORDER BY id DESC LIMIT 100')]}
c.close();print(json.dumps(out,ensure_ascii=False))
