// Browser-only DOCX export. No network and no external libraries.
function zipDocx(parts){
 const encoder=new TextEncoder(),chunks=[],central=[];let offset=0;
 const crc=b=>{let c=0xffffffff;for(let v of b){c^=v;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;};
 const head=n=>({a:new Uint8Array(n),get v(){return new DataView(this.a.buffer)}});
 const now=new Date(),date=((Math.max(1980,now.getFullYear())-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate(),time=(now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1);
 for(let[name,text]of Object.entries(parts)){let n=encoder.encode(name),b=encoder.encode(text),c=crc(b),l=head(30);l.v.setUint32(0,0x04034b50,true);l.v.setUint16(4,20,true);l.v.setUint16(6,0x800,true);l.v.setUint16(10,time,true);l.v.setUint16(12,date,true);l.v.setUint32(14,c,true);l.v.setUint32(18,b.length,true);l.v.setUint32(22,b.length,true);l.v.setUint16(26,n.length,true);chunks.push(l.a,n,b);
 let h=head(46);h.v.setUint32(0,0x02014b50,true);h.v.setUint16(4,20,true);h.v.setUint16(6,20,true);h.v.setUint16(8,0x800,true);h.v.setUint16(12,time,true);h.v.setUint16(14,date,true);h.v.setUint32(16,c,true);h.v.setUint32(20,b.length,true);h.v.setUint32(24,b.length,true);h.v.setUint16(28,n.length,true);h.v.setUint32(42,offset,true);central.push(h.a,n);offset+=30+n.length+b.length;}
 const count=Object.keys(parts).length,centralSize=central.reduce((n,b)=>n+b.length,0),e=head(22);e.v.setUint32(0,0x06054b50,true);e.v.setUint16(8,count,true);e.v.setUint16(10,count,true);e.v.setUint32(12,centralSize,true);e.v.setUint32(16,offset,true);return new Blob([...chunks,...central,e.a],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});
}
function finalDocx(data,rows,questions,verdict,jury){
 if(!data.DocxParts)throw new Error('В этом отчёте нет шаблона Word. Выполните проверку новой версией программы.');
 const parts={...data.DocxParts},parser=new DOMParser(),xml=parser.parseFromString(parts['word/document.xml'],'application/xml'),ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';
 if(xml.getElementsByTagName('parsererror').length)throw new Error('Ошибка шаблона Word.');
 const all=(e,n)=>Array.from(e.getElementsByTagNameNS(ns,n));
 function para(text,style='Cell'){let p=xml.createElementNS(ns,'w:p'),pr=xml.createElementNS(ns,'w:pPr'),s=xml.createElementNS(ns,'w:pStyle');s.setAttributeNS(ns,'w:val',style);pr.appendChild(s);p.appendChild(pr);let r=xml.createElementNS(ns,'w:r'),t=xml.createElementNS(ns,'w:t');t.textContent=text;r.appendChild(t);p.appendChild(r);return p;}
 function setCell(cell,text){for(let p of all(cell,'p'))p.parentNode.removeChild(p);cell.appendChild(para(text));}
 function replacePrefix(prefix,text){let p=all(xml,'p').find(p=>p.textContent.startsWith(prefix));if(p)p.parentNode.replaceChild(para(text,'Normal'),p);}
 replacePrefix('Автоматическая часть','Лист заполнен жюри   '+jury);
 replacePrefix('НП означает','Все 20 критериев проверены жюри. Автоматические рекомендации сохранены отдельно от подтверждённых баллов. Итог ниже учитывает ответы и обязательные ограничения.');
 let table=all(xml,'tbl')[0],trs=all(table,'tr');if(trs.length!==21||rows.length!==20)throw new Error('В листе должно быть 20 критериев.');
 rows.forEach((x,i)=>{let c=all(trs[i+1],'tc');setCell(c[3],String(x.score.value));if(x.note.value.trim())setCell(c[4],x.r.Reason+' Жюри: '+x.note.value.trim());});
 const qt=all(xml,'tbl').find(t=>all(t,'tr')[0].textContent.startsWith('Вопрос'));if(!qt)throw new Error('Не найдена таблица вопросов.');
 all(qt,'tr').slice(1).forEach((r,i)=>{let c=all(r,'tc');setCell(c[1],questions[i].text.value.trim());setCell(c[2],questions[i].score.value);});
 replacePrefix('Баллы проекта после','Баллы проекта: '+verdict.Project+' / 100. Сумма ответов: '+(verdict.Oral>=0?'+':'')+verdict.Oral+'.');
 replacePrefix('Итоговые баллы','Итог с учётом ответов: '+verdict.Total+' баллов. Оценка после ограничений: '+verdict.Grade+'.');
 replacePrefix('Применённое ограничение','Применённые ограничения: '+(verdict.Reasons.join(' ')||'Ограничения не снизили оценку.'));
 replacePrefix('ОКОНЧАТЕЛЬНАЯ ОЦЕНКА','ОКОНЧАТЕЛЬНАЯ ОЦЕНКА: '+verdict.Grade+'. Член жюри: '+jury+'.');
 replacePrefix('Подпись:','Подпись: __________________. Дата заполнения: '+new Date().toLocaleDateString('ru-RU')+'.');
 parts['word/document.xml']=new XMLSerializer().serializeToString(xml);return zipDocx(parts);
}
