using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Security.Cryptography;
using Renci.SshNet;
namespace StandAudit {
 public class RemoteResult {public int Code;public string Output="",Error="";}
 public static class Remote {
  public static string Probe(string host,int port,string user) {
   string key=null;
   using(var c=new SshClient(host,port,user,"")) {
    c.ConnectionInfo.Timeout=TimeSpan.FromSeconds(6);
    c.HostKeyReceived+=(s,e)=>{key=e.FingerPrintSHA256;e.CanTrust=false;};
    try{c.Connect();}catch{if(key==null)throw;}
   }
   if(key==null)throw new Exception("Не получен ключ SSH сервера.");return key;
  }
  public static RemoteResult Run(string host,int port,string user,string password,string expected,string command) {
   if(String.IsNullOrEmpty(expected))throw new Exception("Сначала подтвердите SSH ключ сервера.");
   using(var c=new SshClient(host,port,user,password)) {
    c.ConnectionInfo.Timeout=TimeSpan.FromSeconds(8);
    c.HostKeyReceived+=(s,e)=>{e.CanTrust=String.Equals(expected,e.FingerPrintSHA256,StringComparison.Ordinal);};c.Connect();
    using(var cmd=c.CreateCommand(command)) {cmd.CommandTimeout=TimeSpan.FromSeconds(25);string output=cmd.Execute();
     return new RemoteResult{Code=cmd.ExitStatus??-1,Output=output.Length>2000000?output.Substring(0,2000000):output,Error=cmd.Error.Length>300?"Ошибка удалённой команды; проверьте права доступа.":cmd.Error};}
   }
  }
 }

 public static class GitLocal {
  public static string Quote(string s){var b=new StringBuilder("\"");int slashes=0;foreach(char c in s){if(c=='\\'){slashes++;continue;}if(c=='\"'){b.Append('\\',slashes*2+1);b.Append(c);}else{b.Append('\\',slashes);b.Append(c);}slashes=0;}b.Append('\\',slashes*2);b.Append('"');return b.ToString();}
  public static RemoteResult Read(string executable,string folder,string[] args){
   string cmd=args.Length>0?args[0]:"";
   if(!new[]{"rev-parse","symbolic-ref","ls-tree","cat-file","config","ls-remote"}.Contains(cmd))throw new ArgumentException("Команда Git не разрешена.");
   if(cmd=="config"&&(args.Length!=3||args[1]!="--get"||args[2]!="remote.origin.url"))throw new ArgumentException("Разрешено только чтение origin.");
   if(cmd=="cat-file"&&(args.Length!=3||(args[1]!="blob"&&args[1]!="-s")||!System.Text.RegularExpressions.Regex.IsMatch(args[2],"^[a-fA-F0-9]{40,64}$")))throw new ArgumentException("Неверный объект Git.");
   if(cmd=="ls-remote") {Uri u;if(args.Length!=4||!Uri.TryCreate(args[2],UriKind.Absolute,out u)||(u.Scheme!="https"&&u.Scheme!="http")||u.UserInfo!=""||u.Query!=""||u.Fragment!=""||!args[3].StartsWith("refs/heads/"))throw new ArgumentException("Удалённо разрешено только чтение ветки HTTP(S) без встроенных паролей.");}
   var opts=new List<string>{"-c","core.fsmonitor=false","-c","core.hooksPath=/nonexistent/standchecker-hooks","-c","credential.helper=","-c","core.askPass=","-c","protocol.allow=never","-c","protocol.http.allow=always","-c","protocol.https.allow=always","-c","http.sslVerify=true","-c","http.followRedirects=false","-c","http.extraHeader=","-c","http.proxy=","-C",cmd=="ls-remote"?Path.GetTempPath():Path.GetFullPath(folder)};opts.AddRange(args);
   var psi=new ProcessStartInfo(executable,String.Join(" ",opts.Select(Quote))){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8,WorkingDirectory=Path.GetTempPath()};
   foreach(string k in psi.EnvironmentVariables.Keys.Cast<string>().ToArray()){if(k.StartsWith("GIT_",StringComparison.OrdinalIgnoreCase))psi.EnvironmentVariables.Remove(k);}
   psi.EnvironmentVariables["GIT_TERMINAL_PROMPT"]="0";psi.EnvironmentVariables["GCM_INTERACTIVE"]="Never";psi.EnvironmentVariables["GIT_CONFIG_NOSYSTEM"]="1";psi.EnvironmentVariables["GIT_CONFIG_GLOBAL"]=Environment.OSVersion.Platform==PlatformID.Win32NT?"NUL":"/dev/null";psi.EnvironmentVariables["GIT_NO_REPLACE_OBJECTS"]="1";
   using(var p=new Process{StartInfo=psi}) {p.Start();var output=p.StandardOutput.ReadToEndAsync();var error=p.StandardError.ReadToEndAsync();if(!p.WaitForExit(20000)){try{p.Kill();}catch{}return new RemoteResult{Code=-1,Error="Git timeout"};}string text=output.Result;return new RemoteResult{Code=p.ExitCode,Output=text.Length<=3000000?text:"",Error=p.ExitCode==0?"":"Не удалось прочитать Git или удалённую ветку."};}
  }
 }

}
