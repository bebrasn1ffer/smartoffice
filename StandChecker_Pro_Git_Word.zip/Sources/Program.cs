﻿using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Drawing;
using System.Diagnostics;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace CollegeStandCheckerPro {
 public class Profile {
  public string Name="Новый стенд", Student="", Iot="192.168.30.10", Ctrl="192.168.20.10", Db="192.168.20.20", Mon="192.168.20.30", Grafana="", Flow="";
  public string RepoFolder=""; public bool ActiveTests=false,AlertTests=false; public int SshPort=22; public string SshUser="root",GrafUser="admin"; public Dictionary<string,string> KnownHosts=new Dictionary<string,string>();
  public decimal Threshold=30; public bool Greater=false, Offline=false;
 }
 public class AccessOptions {public string SshUser="root",SshPassword="",GrafUser="admin",GrafPassword="",NrToken="";public int Port=22;public bool ActiveTests=false,AlertTests=false;}
 public class State { public List<Profile> Profiles=new List<Profile>(); public string Selected=""; }
 public static class Util {
  public static string BaseUrl(string value,int port) {
   value=(value??"").Trim(); if(value.Length==0)throw new ArgumentException("Адрес не заполнен.");
   if(!value.Contains("://")) {
    Uri probe;
    if(!Uri.TryCreate("http://"+value,UriKind.Absolute,out probe))throw new ArgumentException("Неверный адрес: "+value);
    // An explicit port is preserved. Bare IPv4/DNS gets the service's default port.
    bool explicitPort=value.StartsWith("[") ? value.Contains("]:") : value.Split('/')[0].Contains(":");
    var b=new UriBuilder(probe);if(!explicitPort)b.Port=port;value=b.Uri.AbsoluteUri;
   }
   Uri u;
   if(!Uri.TryCreate(value,UriKind.Absolute,out u)||(u.Scheme!="http"&&u.Scheme!="https")||u.UserInfo!=""||u.Query!=""||u.Fragment!="")
    throw new ArgumentException("Нужен IP или адрес http(s) без пароля, параметров и #.");
   return value.TrimEnd('/');
  }
  public static string GrafanaUrl(string mon,string custom) {
   if(!String.IsNullOrWhiteSpace(custom))return BaseUrl(custom,3000);
   var u=new UriBuilder(BaseUrl(mon,9090));u.Port=3000;return u.Uri.AbsoluteUri.TrimEnd('/');
  }
  public static Dictionary<string,object> Config(Profile p) {
   return new Dictionary<string,object>{{"StudentName",p.Student},{"ProfileName",p.Name},{"RepoFolder",p.RepoFolder},{"FlowsPath",p.Flow},{"NodeRedUrl",BaseUrl(p.Iot,1880)},{"CtrlUrl",BaseUrl(p.Ctrl,8080)},
    {"DbUrl",BaseUrl(p.Db,8081)},{"PrometheusUrl",BaseUrl(p.Mon,9090)},{"GrafanaUrl",GrafanaUrl(p.Mon,p.Grafana)},
    {"Threshold",p.Threshold},{"Comparison",p.Greater?"gt":"ge"},{"ObserveSeconds",20},{"SampleInterval",5},{"TimeoutSeconds",4},
    {"ExpectedPeriod",5},{"MaxSensorAge",20},{"FanWaitSeconds",45},{"KnownHosts",p.KnownHosts},{"SshPort",p.SshPort},{"ActiveTests",p.ActiveTests},{"AlertTests",p.AlertTests},{"Offline",p.Offline}};
  }
 }
 public class MainWindow:Form {
  readonly JavaScriptSerializer json=new JavaScriptSerializer();
  readonly string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CollegeStandCheckerPro");
  State state=new State(); AccessOptions access=new AccessOptions(); Dictionary<string,string> knownHosts=new Dictionary<string,string>(); bool cancelRequested=false;string recoveryPath="",repoFolder=""; ComboBox profiles; TextBox student,iot,ctrl,db,mon,grafana,flow,log; NumericUpDown threshold; CheckBox greater,offline;
  Button run,save,remove,browse,report,folder; Label status; ProgressBar progress; Process child; bool running,loading;string reportPath="",runDirectory="";
  readonly List<Control> inputs=new List<Control>();
  public MainWindow() {
   Text="StandChecker Pro • технические критерии и лист жюри";
   ClientSize=new Size(900,790); MinimumSize=new Size(780,780);StartPosition=FormStartPosition.CenterScreen;Font=new Font("Segoe UI",10);AutoScaleMode=AutoScaleMode.Dpi;
   var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(18),ColumnCount=1,RowCount=5};
   layout.RowStyles.Add(new RowStyle(SizeType.Absolute,48));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,345));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,52));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,52));Controls.Add(layout);
   var hint=new Label{Dock=DockStyle.Fill,Text="Адреса сохраняются. В «Доступы и тесты» можно добавить SSH, вход Grafana и разрешить испытания.\nБез доступа пункт остаётся непроверенным. Итоговую оценку подтверждает жюри.",AutoSize=false};layout.Controls.Add(hint);
   var fields=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3,RowCount=10};fields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,195));fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));fields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,155));
   for(int i=0;i<10;i++)fields.RowStyles.Add(new RowStyle(SizeType.Absolute,i==9?40:33));layout.Controls.Add(fields);
   profiles=new ComboBox{Dock=DockStyle.Fill,DropDownStyle=ComboBoxStyle.DropDown};inputs.Add(profiles);
   save=new Button{Text="Сохранить стенд",Dock=DockStyle.Fill};inputs.Add(save);Row(fields,0,"Название стенда",profiles,save);
   student=Field();remove=new Button{Text="Git-репозиторий…",Dock=DockStyle.Fill};inputs.Add(remove);Row(fields,1,"Студент / группа",student,remove);
   iot=Field();Row(fields,2,"IOT — Node-RED :1880",iot,null);
   ctrl=Field();Row(fields,3,"CTRL — приёмник :8080",ctrl,null);
   db=Field();Row(fields,4,"DB — база :8081",db,null);
   mon=Field();Row(fields,5,"MON — Prometheus :9090",mon,null);
   grafana=Field();Row(fields,6,"Grafana, если другой адрес",grafana,new Label{Dock=DockStyle.Fill,Text="Пусто = MON:3000",TextAlign=ContentAlignment.MiddleLeft});
   flow=Field();flow.ReadOnly=true;browse=new Button{Text="Выбрать / убрать…",Dock=DockStyle.Fill};inputs.Add(browse);Row(fields,7,"Экспорт flows.json",flow,browse);
   var fan=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};threshold=new NumericUpDown{Minimum=-100,Maximum=200,DecimalPlaces=1,Value=30,Width=80};greater=new CheckBox{Text="строго выше (>)",AutoSize=true,Padding=new Padding(10,3,0,0)};fan.Controls.Add(threshold);fan.Controls.Add(greater);inputs.Add(threshold);inputs.Add(greater);Row(fields,8,"Порог включения FAN",fan,null);
   offline=new CheckBox{Text="Только файл flows.json, без проверки служб по сети",Dock=DockStyle.Fill};inputs.Add(offline);Row(fields,9,"Режим проверки",offline,null);
   var buttons=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};run=new Button{Text="Проверить",Width=120,Height=38,BackColor=Color.FromArgb(28,105,153),ForeColor=Color.White,FlatStyle=FlatStyle.Flat};report=new Button{Text="Открыть отчёт",Width=130,Height=38,Enabled=false};folder=new Button{Text="Папка отчётов",Width=130,Height=38};var help=new Button{Text="Что проверяется?",Width=110,Height=38};var accessButton=new Button{Text="Доступы и тесты",Width=145,Height=38};var restoreButton=new Button{Text="Восстановить",Width=125,Height=38};inputs.Add(accessButton);inputs.Add(restoreButton);buttons.Controls.AddRange(new Control[]{run,report,folder,accessButton,restoreButton,help});accessButton.Click+=(s,e)=>AccessDialog();restoreButton.Click+=(s,e)=>{using(var f=new OpenFileDialog{Title="Выберите recovery.json незавершённого опыта",Filter="Восстановление (recovery.json)|recovery.json",InitialDirectory=Path.Combine(root,"Reports")}){if(f.ShowDialog()==DialogResult.OK){recoveryPath=f.FileName;StartCheck();}}};layout.Controls.Add(buttons);
   log=new TextBox{Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,WordWrap=false,Dock=DockStyle.Fill,Font=new Font("Consolas",9),BackColor=Color.FromArgb(247,249,251)};layout.Controls.Add(log);
   var bottom=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2};status=new Label{Dock=DockStyle.Fill,Text="Готово к проверке. Работа студента не изменяется."};progress=new ProgressBar{Dock=DockStyle.Bottom,Height=10,Style=ProgressBarStyle.Blocks};bottom.Controls.Add(status);bottom.Controls.Add(progress);layout.Controls.Add(bottom);
   save.Click+=(s,e)=>{try{SaveProfile();status.Text="Настройки стенда сохранены.";}catch(Exception x){Error(x.Message);}};
   remove.Click+=(s,e)=>{if(repoFolder.Length>0){var choice=MessageBox.Show("Выбрать другой репозиторий? Нет — убрать его из профиля.","Git",MessageBoxButtons.YesNoCancel);if(choice==DialogResult.Cancel)return;if(choice==DialogResult.No){repoFolder="";remove.Text="Git-репозиторий…";return;}}using(var d=new FolderBrowserDialog{Description="Выберите локальный репозиторий с .git. Проверяется HEAD, а не незакоммиченные файлы.",SelectedPath=repoFolder}){if(d.ShowDialog()==DialogResult.OK){repoFolder=d.SelectedPath;remove.Text="Git выбран";status.Text="Git: "+repoFolder;}}};
   profiles.SelectedIndexChanged+=(s,e)=>{if(!loading){var p=state.Profiles.FirstOrDefault(x=>x.Name==profiles.Text);if(p!=null)LoadProfile(p);}};
   browse.Click+=(s,e)=>ChooseFlow();run.Click+=(s,e)=>{if(running)StopCheck();else StartCheck();};report.Click+=(s,e)=>OpenReport();folder.Click+=(s,e)=>OpenFolder();
   help.Text="Открыть Word";help.Click+=(s,e)=>{try{string file=Path.Combine(runDirectory,"report.docx");if(!File.Exists(file)){Error("Сначала выполните проверку. После заполнения HTML используйте кнопку «Скачать Word» в самом листе.");return;}Process.Start(new ProcessStartInfo(file){UseShellExecute=true});}catch(Exception x){Error(x.Message);}};
   FormClosing+=(s,e)=>{if(running){e.Cancel=true;if(MessageBox.Show("Сначала завершите проверку и восстановление таймеров. Запросить отмену?", "Выход", MessageBoxButtons.YesNo)==DialogResult.Yes)StopCheck(false);}};
   LoadState();
  }
  TextBox Field(){var t=new TextBox{Dock=DockStyle.Fill};inputs.Add(t);return t;}
  static void Row(TableLayoutPanel t,int n,string title,Control c,Control extra){t.Controls.Add(new Label{Text=title,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,n);t.Controls.Add(c,1,n);if(extra!=null)t.Controls.Add(extra,2,n);else t.SetColumnSpan(c,2);}
  void Error(string text){MessageBox.Show(text,"Не удалось выполнить действие",MessageBoxButtons.OK,MessageBoxIcon.Warning);}
  Profile Current(){return new Profile{Name=profiles.Text.Trim(),Student=student.Text.Trim(),Iot=iot.Text.Trim(),Ctrl=ctrl.Text.Trim(),Db=db.Text.Trim(),Mon=mon.Text.Trim(),Grafana=grafana.Text.Trim(),Flow=flow.Text.Trim(),RepoFolder=repoFolder,Threshold=threshold.Value,Greater=greater.Checked,Offline=offline.Checked,SshUser=access.SshUser,GrafUser=access.GrafUser,SshPort=access.Port,ActiveTests=access.ActiveTests,AlertTests=access.AlertTests,KnownHosts=knownHosts};}
  void LoadProfile(Profile p){loading=true;profiles.Text=p.Name;student.Text=p.Student;iot.Text=p.Iot;ctrl.Text=p.Ctrl;db.Text=p.Db;mon.Text=p.Mon;grafana.Text=p.Grafana;flow.Text=p.Flow;repoFolder=p.RepoFolder??"";remove.Text=repoFolder.Length>0?"Git выбран":"Git-репозиторий…";threshold.Value=Math.Max(threshold.Minimum,Math.Min(threshold.Maximum,p.Threshold));greater.Checked=p.Greater;offline.Checked=p.Offline;access=new AccessOptions{SshUser=p.SshUser,GrafUser=p.GrafUser,Port=p.SshPort,ActiveTests=p.ActiveTests,AlertTests=p.AlertTests};knownHosts=p.KnownHosts??new Dictionary<string,string>();loading=false;}
  void RefreshProfiles(){loading=true;string selected=profiles.Text;profiles.Items.Clear();foreach(var p in state.Profiles)profiles.Items.Add(p.Name);profiles.Text=selected;loading=false;}
  void LoadState(){try{Directory.CreateDirectory(root);string f=Path.Combine(root,"profiles.json");if(File.Exists(f))state=json.Deserialize<State>(File.ReadAllText(f,Encoding.UTF8))??new State();if(state.Profiles==null)state.Profiles=new List<Profile>();}catch{state=new State();status.Text="Настройки не прочитаны: загружены примеры адресов. Сохраните профиль заново.";}
   if(state.Profiles.Count==0){var p=new Profile();string adjacent=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"flows.json");if(File.Exists(adjacent))p.Flow=adjacent;state.Profiles.Add(p);}RefreshProfiles();LoadProfile(state.Profiles.FirstOrDefault(p=>p.Name==state.Selected)??state.Profiles[0]);}
  void Persist(){Directory.CreateDirectory(root);string f=Path.Combine(root,"profiles.json");string temp=f+".tmp";File.WriteAllText(temp,json.Serialize(state),new UTF8Encoding(true));if(File.Exists(f))File.Replace(temp,f,null);else File.Move(temp,f);}
  void SaveProfile(){var p=Current();if(p.Name.Length==0)throw new ArgumentException("Введите название стенда, например: Иванов, 54-15.");if(p.Name.Length>120)throw new ArgumentException("Название стенда: не больше 120 символов.");Util.Config(p);int i=state.Profiles.FindIndex(x=>x.Name==p.Name);if(i>=0)state.Profiles[i]=p;else state.Profiles.Add(p);state.Selected=p.Name;Persist();RefreshProfiles();profiles.Text=p.Name;}
  void ChooseFlow(){if(flow.Text.Length>0){var a=MessageBox.Show("Выбрать другой файл?\nДа — выбрать. Нет — убрать файл и использовать GET /flows. Отмена — оставить.","Экспорт Node-RED",MessageBoxButtons.YesNoCancel);if(a==DialogResult.Cancel)return;if(a==DialogResult.No){flow.Text="";return;}}
   using(var d=new OpenFileDialog{Filter="Node-RED JSON (*.json)|*.json|Все файлы (*.*)|*.*",Title="Выберите экспорт ВСЕХ потоков Node-RED",CheckFileExists=true}){if(d.ShowDialog()==DialogResult.OK)flow.Text=d.FileName;}}
  void Append(string text){if(IsDisposed)return;if(InvokeRequired){try{BeginInvoke(new Action<string>(Append),text);}catch(InvalidOperationException){}return;}log.AppendText(text+Environment.NewLine);}
  void SetRunning(bool b){running=b;run.Enabled=true;foreach(var c in inputs)c.Enabled=!b;run.Text=b?"Остановить":"Проверить";progress.Style=b?ProgressBarStyle.Marquee:ProgressBarStyle.Blocks;report.Enabled=!b&&File.Exists(reportPath);}
  async void StartCheck(){try{
   cancelRequested=false;
   var p=Current();if(p.Name.Length==0){profiles.Text=String.IsNullOrEmpty(p.Student)?"Мой стенд":p.Student;p=Current();}
   if(recoveryPath.Length==0&&p.Flow.Length>0&&!File.Exists(p.Flow))throw new ArgumentException("Файл flows.json не найден. Выберите файл заново или уберите его, чтобы проверить GET /flows.");
   if(recoveryPath.Length==0&&p.Offline&&p.Flow.Length==0)throw new ArgumentException("Для проверки без сети выберите flows.json.");
   var cfg=Util.Config(p);
   if(recoveryPath.Length==0){string pending=FindPending(p);if(pending.Length>0)throw new Exception("Есть незавершённый опыт этого профиля. Сначала нажмите «Восстановить» и выберите: "+pending);}
   SaveProfile();SetRunning(true);
   if(access.SshPassword.Length>0&&!p.Offline&&recoveryPath.Length==0){foreach(var host in new[]{new Uri(Util.BaseUrl(p.Iot,1880)).Host,new Uri(Util.BaseUrl(p.Ctrl,8080)).Host,new Uri(Util.BaseUrl(p.Db,8081)).Host,new Uri(Util.BaseUrl(p.Mon,9090)).Host}.Distinct()){
    if(cancelRequested)throw new OperationCanceledException();status.Text="Проверяю ключ SSH "+host+"…";
    string key;try{key=await Task.Run(()=>StandAudit.Remote.Probe(host,access.Port,access.SshUser));}catch{Append("SSH "+host+": ключ не получен. Связанные критерии останутся НП.");continue;}
    if(cancelRequested)throw new OperationCanceledException();string name=host+":"+access.Port;
    if(knownHosts.ContainsKey(name)){if(knownHosts[name]!=key)throw new Exception("Ключ SSH "+name+" изменился. Соединение запрещено. Проверьте выбранный стенд и ключ ВМ; для другого изолированного стенда создайте новый профиль.");}
    else {if(MessageBox.Show("Сверьте ключ SSH ВМ "+name+":\n"+key+"\n\nНа ВМ сравните SHA256 вывод ssh-keygen -lf для публичного host-ключа в /etc/ssh/ (ed25519 или rsa).\nКлюч принадлежит нужной ВМ?","Первое подключение SSH",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)knownHosts[name]=key;else Append("SSH "+host+": ключ не подтверждён, доступ не используется.");}
   }SaveProfile();cfg=Util.Config(Current());}
   if(cancelRequested)throw new OperationCanceledException();
   var ps=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),@"WindowsPowerShell\v1.0\powershell.exe");if(!File.Exists(ps))throw new FileNotFoundException("Не найден Windows PowerShell. Требуется Windows 10 с PowerShell 5.1 и .NET Framework 4.8.");
   runDirectory=Path.Combine(root,"Reports",DateTime.Now.ToString("yyyyMMdd_HHmmss")+"_"+Guid.NewGuid().ToString("N").Substring(0,6));Directory.CreateDirectory(runDirectory);
   string engine=Path.Combine(Program.RuntimePath,"Advanced.ps1"),conf=Path.Combine(runDirectory,"run.json"),secret=Path.Combine(runDirectory,"access.bin");
   File.WriteAllText(conf,json.Serialize(cfg),new UTF8Encoding(true));byte[] plain=Encoding.UTF8.GetBytes(json.Serialize(access));try{File.WriteAllBytes(secret,ProtectedData.Protect(plain,null,DataProtectionScope.CurrentUser));}finally{Array.Clear(plain,0,plain.Length);}
   reportPath="";log.Clear();Append("Проверка: "+p.Name);Append(p.ActiveTests?"Активные испытания разрешены. Не изменяйте поток до завершения. Отмена выполняет восстановление.":"Чтение без остановки датчиков. Для большей полноты укажите доступы и разрешите испытания.");status.Text="Выполняется проверка; протокол появится ниже. Ожидайте несколько минут.";SetRunning(true);
   string args="-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File \""+engine+"\" -ConfigPath \""+conf+"\" -SecretsPath \""+secret+"\" -OutputDirectory \""+runDirectory+"\"";
   if(recoveryPath.Length>0)args+=" -RecoveryPath \""+recoveryPath+"\"";recoveryPath="";
   var psi=new ProcessStartInfo(ps,args){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8,WorkingDirectory=runDirectory};
   var process=new Process{StartInfo=psi,EnableRaisingEvents=true};child=process;process.OutputDataReceived+=(s,e)=>{if(e.Data!=null)Append(e.Data);};process.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)Append("PowerShell: "+e.Data);};
   process.Exited+=(s,e)=>{process.WaitForExit();int exit=process.ExitCode;try{BeginInvoke(new Action(()=>Finish(process,exit)));}catch(InvalidOperationException){}};
   process.Start();process.BeginOutputReadLine();process.BeginErrorReadLine();
  }catch(OperationCanceledException){SetRunning(false);status.Text="Подготовка отменена.";}catch(Exception x){SetRunning(false);Error(x.Message);}}
  void Finish(Process p,int code){if(child!=p){p.Dispose();return;}child=null;p.Dispose();SetRunning(false);
   var latest=Directory.Exists(runDirectory)?Directory.GetFiles(runDirectory,"report.html").OrderByDescending(f=>f).FirstOrDefault():null;reportPath=latest??"";report.Enabled=File.Exists(reportPath);
   if(!report.Enabled){status.Text="Проверка завершилась без отчёта. Посмотрите сообщения в окне.";return;}
   string summary="Проверка завершена. Открылся отчёт.";
   try{string data=Path.ChangeExtension(reportPath,".json");var result=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(data,Encoding.UTF8));summary="Подтверждено: "+result["AutomaticPoints"]+" баллов. Word-лист создан; жюри дополняет HTML и скачивает итоговый Word.";}catch{}
   status.Text=summary;OpenReport();
  }
  void StopCheck(){StopCheck(true);}
  void StopCheck(bool confirm){if(confirm&&MessageBox.Show("Отменить проверку? Дождитесь восстановления таймеров и отчёта; не завершайте процесс принудительно.","Отмена",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;cancelRequested=true;if(child!=null&&Directory.Exists(runDirectory))File.WriteAllText(Path.Combine(runDirectory,"cancel.flag"),"cancel");status.Text="Запрошена отмена. Дождитесь завершения и восстановления.";run.Enabled=false;}
  string FindPending(Profile p){string baseDir=Path.Combine(root,"Reports");if(!Directory.Exists(baseDir))return "";foreach(string file in Directory.GetFiles(baseDir,"recovery.json",SearchOption.AllDirectories).OrderByDescending(x=>x).Take(200)){try{var item=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(file,Encoding.UTF8));if(item.ContainsKey("Restored")&&!(bool)item["Restored"]&&item.ContainsKey("ProfileName")&&(string)item["ProfileName"]==p.Name&&(string)item["NodeRedUrl"]==Util.BaseUrl(p.Iot,1880))return file;}catch{}}return "";}
  void AccessDialog(){
   using(var f=new Form{Text="Доступы и активные испытания",Size=new Size(730,600),MinimumSize=new Size(650,580),StartPosition=FormStartPosition.CenterParent,Font=Font}){
    var t=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(16),ColumnCount=2,RowCount=12};t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,210));t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));f.Controls.Add(t);
    var note=new Label{Text="Необязательно: без доступа пункт остаётся непроверенным. SSH использует одну существующую учётную запись на четырёх ВМ; права не повышаются. Пароли и токен не сохраняются в профиле.",Dock=DockStyle.Fill};t.Controls.Add(note,0,0);t.SetColumnSpan(note,2);t.RowStyles.Add(new RowStyle(SizeType.Absolute,70));
    TextBox su=DialogField(t,1,"Пользователь SSH",access.SshUser,false),sp=DialogField(t,2,"Пароль SSH",access.SshPassword,true),gu=DialogField(t,3,"Пользователь Grafana",access.GrafUser,false),gp=DialogField(t,4,"Пароль Grafana",access.GrafPassword,true),nt=DialogField(t,5,"Существующий токен Node-RED",access.NrToken,true);
    var port=new NumericUpDown{Minimum=1,Maximum=65535,Value=access.Port,Dock=DockStyle.Fill};t.Controls.Add(new Label{Text="Порт SSH",Dock=DockStyle.Fill},0,6);t.Controls.Add(port,1,6);t.RowStyles.Add(new RowStyle(SizeType.Absolute,34));
    var active=new CheckBox{Text="Разрешить временно менять repeat/once TEMP/HUM и посылать контрольные значения",Checked=access.ActiveTests,Dock=DockStyle.Fill};t.Controls.Add(active,0,7);t.SetColumnSpan(active,2);t.RowStyles.Add(new RowStyle(SizeType.Absolute,48));
    var alerts=new CheckBox{Text="Также проверить остановку TEMP и HUM и срабатывание алертов",Checked=access.AlertTests,Dock=DockStyle.Fill};t.Controls.Add(alerts,0,8);t.SetColumnSpan(alerts,2);t.RowStyles.Add(new RowStyle(SizeType.Absolute,36));
    var warning=new Label{Text="В опытах могут прийти настоящие письма. В SQLite останутся контрольные записи. Таймеры возвращаются в finally. При обрыве питания или принудительном закрытии используйте recovery.json и «Восстановить». Не редактируйте поток одновременно с испытаниями.",Dock=DockStyle.Fill};t.Controls.Add(warning,0,9);t.SetColumnSpan(warning,2);t.RowStyles.Add(new RowStyle(SizeType.Absolute,85));
    var ok=new Button{Text="Применить",DialogResult=DialogResult.OK,Dock=DockStyle.Fill};var cancel=new Button{Text="Отмена",DialogResult=DialogResult.Cancel,Dock=DockStyle.Fill};t.Controls.Add(cancel,0,10);t.Controls.Add(ok,1,10);t.RowStyles.Add(new RowStyle(SizeType.Absolute,38));f.AcceptButton=ok;f.CancelButton=cancel;
    if(f.ShowDialog(this)==DialogResult.OK)access=new AccessOptions{SshUser=su.Text.Trim(),SshPassword=sp.Text,GrafUser=gu.Text.Trim(),GrafPassword=gp.Text,NrToken=nt.Text.Trim(),Port=(int)port.Value,ActiveTests=active.Checked,AlertTests=active.Checked&&alerts.Checked};
   }
  }
  static TextBox DialogField(TableLayoutPanel t,int row,string name,string value,bool secret){t.RowStyles.Add(new RowStyle(SizeType.Absolute,34));t.Controls.Add(new Label{Text=name,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,row);var box=new TextBox{Text=value,Dock=DockStyle.Fill,UseSystemPasswordChar=secret};t.Controls.Add(box,1,row);return box;}
  void OpenReport(){try{if(File.Exists(reportPath))Process.Start(new ProcessStartInfo(reportPath){UseShellExecute=true});}catch(Exception x){Error("Не удалось открыть отчёт: "+x.Message);}}
  void OpenFolder(){try{string path=Path.Combine(root,"Reports");Directory.CreateDirectory(path);Process.Start(new ProcessStartInfo("explorer.exe","\""+path+"\""){UseShellExecute=true});}catch(Exception x){Error(x.Message);}}
 }
 public static class Program {
  public static string RuntimePath="";
  public static void Extract(){
   var a=Assembly.GetExecutingAssembly();string hash;using(var sha=SHA256.Create()){hash=BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(a.Location))).Replace("-","").Substring(0,16);}
   RuntimePath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CollegeStandCheckerPro","Runtime",hash);Directory.CreateDirectory(RuntimePath);
   foreach(var name in a.GetManifestResourceNames()){if(!name.StartsWith("assets/"))continue;string rel=name.Substring(7).Replace('/',Path.DirectorySeparatorChar),path=Path.Combine(RuntimePath,rel);Directory.CreateDirectory(Path.GetDirectoryName(path));if(!File.Exists(path)){using(var src=a.GetManifestResourceStream(name))using(var dst=File.Create(path))src.CopyTo(dst);}}
   AppDomain.CurrentDomain.AssemblyResolve+=(s,e)=>{string name=new AssemblyName(e.Name).Name+".dll",path=Path.Combine(RuntimePath,"lib",name);return File.Exists(path)?Assembly.LoadFrom(path):null;};
  }
  [STAThread]public static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);try{Extract();Application.Run(new MainWindow());}catch(Exception e){MessageBox.Show(e.Message,"Проверка стенда",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
 }
}
