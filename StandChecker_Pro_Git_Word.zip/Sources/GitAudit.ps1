﻿function TextHash([string]$text){$text=$text.TrimStart([char]0xfeff).Replace("`r`n","`n").Replace("`r","`n");$s=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($s.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
function GitRead([string[]]$arguments){return [StandAudit.GitLocal]::Read($script:GitExe,$script:RepoFolder,$arguments)}
function StripSqlComments([string]$text){return [regex]::Replace([regex]::Replace($text,'(?s)/\*.*?\*/',''),'(?m)--[^\r\n]*','')}
function SqlSource($text){$text=StripSqlComments $text;foreach($name in @('measurements','actuator_events')){if($text -notmatch ('(?is)\bCREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?["`\[]?'+$name+'["`\]]?\s*\(')){return $false}};foreach($name in @('device_id','timestamp','received_at','value','unit','state','mode')){if($text -notmatch ('(?i)\b'+$name+'\b')){return $false}};return $true}
function DashboardFingerprint($d){$m=AsMap $d;foreach($k in @('id','version','iteration','time','timepicker')){[void]$m.Remove($k)};return Canonical $m}
function RuleCanon($rule){$m=[ordered]@{};foreach($k in @('uid','title','condition','data','for','labels','isPaused')){$m[$k]=Prop $rule $k};return Canonical $m}
function RulesSource($obj){$array=@();if($obj -is [array]){$array=@($obj)}elseif(Prop $obj 'rules'){$array=@(Prop $obj 'rules')}else{foreach($g in @(Prop $obj 'groups' @())){$array+=@(Prop $g 'rules' @())}}
 foreach($id in @('TEMP-01','HUM-01')){$known=Prop $script:RuleInfo $id;if(-not $known){return $false};$actual=@($script:RawRules|Where-Object{(Prop $_ 'uid') -ceq (Prop $known 'Uid')});$saved=@($array|Where-Object{(Prop $_ 'uid') -ceq (Prop $known 'Uid')});if($actual.Count -ne 1 -or $saved.Count -ne 1 -or (RuleCanon $actual[0]) -cne (RuleCanon $saved[0])){return $false}};return $true}
function GitCheck {
 $script:GitAudit=[ordered]@{Checked=$false;Commit='';Branch='';Remote='НП';Files=@();Matches=@();Notes=@()};$folder=[string](Prop $script:Config 'RepoFolder' '');if(-not $folder){Event 'Git' 'НП' 'Папка локального репозитория не выбрана.';return};$script:RepoFolder=$folder
 try{
  $git=Get-Command git.exe -CommandType Application -ErrorAction SilentlyContinue|Select-Object -First 1;if(-not $git){$git=Get-Command git -CommandType Application -ErrorAction SilentlyContinue|Select-Object -First 1};if(-not $git){throw 'GIT_NOT_INSTALLED'};$script:GitExe=$git.Source
  $head=GitRead @('rev-parse','--verify','HEAD');if($head.Code -ne 0 -or $head.Output.Trim() -notmatch '^[a-f0-9]{40,64}$'){throw 'NO_GIT_COMMIT'};$commit=$head.Output.Trim();$branch=GitRead @('symbolic-ref','--quiet','--short','HEAD');$tree=GitRead @('ls-tree','-r','-z','--full-tree',$commit);if($tree.Code -ne 0){throw 'NO_GIT_TREE'};$script:GitAudit.Checked=$true;$script:GitAudit.Commit=$commit;$script:GitAudit.Branch=$branch.Output.Trim()
  $files=@();foreach($line in $tree.Output.Split([char]0)){if($line -match '^(?<mode>\d+) blob (?<hash>[a-f0-9]{40,64})\t(?<path>.+)$'){$files+=,[pscustomobject]@{Path=$Matches.path;Hash=$Matches.hash;Mode=$Matches.mode}}};$script:GitAudit.Files=@($files.Path)
  $texts=@();foreach($f in @($files|Where-Object{$_.Mode -in @('100644','100755') -and $_.Path -match '(?i)\.(?:json|ya?ml|sql|js|py|md|txt|service|ini|env)$'}|Select-Object -First 150)){CancelCheck;$size=GitRead @('cat-file','-s',$f.Hash);$n=Num $size.Output.Trim();if($size.Code -ne 0 -or $null -eq $n -or $n -gt 1500000){continue};$blob=GitRead @('cat-file','blob',$f.Hash);if($blob.Code -eq 0){$texts+=,[pscustomobject]@{Path=$f.Path;Text=$blob.Output;Hash=(TextHash $blob.Output)}}}
  $groups=[ordered]@{Compose=$false;Flows=$false;CtrlSource=$false;DbSource=$false;SQL=$false;PrometheusConfig=$false;PrometheusService=$false;Dashboard=$false;Rules=$false}
  $matched=[ordered]@{};foreach($k in $groups.Keys){$matched[$k]=$false}
  foreach($f in $texts){$path=$f.Path;$text=$f.Text
   if($path -match '(?i)(?:compose[^/]*|docker-compose[^/]*)\.ya?ml$' -and $text -match '(?m)^\s*services\s*:'){$groups.Compose=$true}
   if($path -match '(?i)\.sql$' -and (SqlSource $text)){$groups.SQL=$true;$matched.SQL=$null -ne $script:SqlAudit}
   if($path -match '(?i)\.js$' -and $text -match '/api/readings'){$groups.CtrlSource=$true}
   if($path -match '(?i)\.py$' -and $text -match 'sqlite3' -and $text -match '/api/history'){$groups.DbSource=$true}
   if($path -match '(?i)\.ya?ml$' -and $text -match 'scrape_configs' -and $text -match 'office-controller'){$groups.PrometheusConfig=$true}
   if($path -match '(?i)\.service$' -and $text -match 'ExecStart=.*prometheus'){$groups.PrometheusService=$true}
   if($path -match '(?i)\.json$'){
    try{$j=$text|ConvertFrom-Json;if(($j -is [array]) -or (Prop $j 'flows')){try{$ns=FlowArray $j;if(@($ns|Where-Object{(Prop $_ 'type') -ceq 'inject'}).Count){$groups.Flows=$true;if($script:LiveFlow -and (Fingerprint $ns) -ceq (Fingerprint (FlowArray $script:LiveFlow))){$matched.Flows=$true}}}catch{}}
     $dash=Prop $j 'dashboard' $j;if(Prop $dash 'panels'){$groups.Dashboard=$true;foreach($live in @($script:DashSnapshots.Values)){if((DashboardFingerprint $dash) -ceq (DashboardFingerprint $live)){$matched.Dashboard=$true}}}
     if(RulesSource $j){$groups.Rules=$true;$matched.Rules=$true}
    }catch{}
   }
   if($path -match '(?i)\.(?:md|txt|json|ya?ml)$' -and $text -match 'TEMP-01' -and $text -match 'HUM-01' -and $text -match 'office_sensor_age_seconds' -and $text -match '\b20\b'){$groups.Rules=$true}
  }
  $composeRoles=0;foreach($role in @('NodeRed','Ctrl','Db')){$a=Prop $script:Audit $role;$remote=@(Prop $a 'files' @());$compose=@($remote|Where-Object{(Prop $_ 'kind') -ceq 'compose'});if(@($compose|Where-Object{$hash=[string](Prop $_ 'hash');@($texts|Where-Object{$_.Hash -ceq $hash}).Count -gt 0}).Count){$composeRoles++}
   foreach($file in @($remote|Where-Object{(Prop $_ 'kind') -ceq 'source'})){if(@($texts|Where-Object{$_.Hash -ceq (Prop $file 'hash')}).Count){if($role -ceq 'Ctrl'){$matched.CtrlSource=$true};if($role -ceq 'Db' -and (Prop $file 'name') -match '(?i)server|storage'){$matched.DbSource=$true}}}}
  $matched.Compose=$composeRoles -eq 3
  foreach($file in @(Prop (Prop $script:Audit 'Mon') 'files' @())){if(@($texts|Where-Object{$_.Hash -ceq (Prop $file 'hash')}).Count){if((Prop $file 'scope') -ceq 'prometheus.service' -and (Prop $file 'kind') -ceq 'unit'){$matched.PrometheusService=$true};if((Prop $file 'scope') -ceq 'prometheus.service' -and (Prop $file 'kind') -ceq 'config'){$matched.PrometheusConfig=$true}}}
  foreach($k in $groups.Keys){$script:GitAudit.Matches+=,[pscustomobject]@{Group=$k;Present=[bool]$groups[$k];MatchesLive=[bool]$matched[$k]}}
  $present=@($groups.Values|Where-Object{$_}).Count;$matches=@($matched.Values|Where-Object{$_}).Count
  if($present -eq 9 -and $matches -eq 9){Award '6.1' 5 'В HEAD есть все 9 групп материалов. Потоки, исходники, Compose и конфигурации сверены со стендом; найдены SQL, экспорт панели и обоих правил.'}elseif($present -gt 0){Award '6.1' 3 ('Коммит прочитан; групп материалов '+$present+'/9, соответствие стенду подтверждено '+$matches+'/9. Неподдержанный формат или несовпадение требует жюри.')}
  $remote=GitRead @('config','--get','remote.origin.url');$url=$null;$remoteOk=$false
  if($remote.Code -eq 0 -and [uri]::TryCreate($remote.Output.Trim(),[UriKind]::Absolute,[ref]$url) -and $url.Scheme -in @('http','https') -and -not $url.UserInfo -and -not $url.Query -and -not $url.Fragment -and $branch.Code -eq 0 -and $branch.Output.Trim() -notmatch '[\x00-\x20]'){
   $refs=GitRead @('ls-remote','--refs',$url.AbsoluteUri,('refs/heads/'+$branch.Output.Trim()));if($refs.Code -eq 0 -and $refs.Output -match ('(?m)^'+[regex]::Escape($commit)+'\s+refs/heads/')){$remoteOk=$true;$script:GitAudit.Remote='Коммит совпадает с удалённой веткой.'}else{$script:GitAudit.Remote='Удалённая ветка недоступна или её HEAD отличается; публикация требует проверки жюри.'}
  }else{$script:GitAudit.Remote='origin отсутствует, не HTTP(S), требует встроенных учётных данных или ветка не определена. Публикация не проверена.'}
  $readmes=@($texts|Where-Object{$_.Path -match '(?i)(^|/)readme(?:\.[^/]*)?$'});$readmeOk=$false
  foreach($f in $readmes){$ok=$true;foreach($key in @('NodeRedUrl','CtrlUrl','DbUrl','PrometheusUrl','GrafanaUrl')){$u=[uri]$script:Cfg[$key];if($f.Text -notmatch [regex]::Escape($u.Host) -or $f.Text -notmatch [regex]::Escape([string]$u.Port)){$ok=$false}};if($ok){$readmeOk=$true}}
  $issues=@();foreach($f in $files){if($f.Path -match '(?i)\.(sqlite3?|db)$' -or $f.Path -match '(?i)(^|/)(node_modules|__pycache__)/'){$issues+=,$f.Path}}
  foreach($f in $texts){if($f.Text -match '-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----' -or $f.Text -match 'https?://[^/\s:@]+:[^@\s/]+@'){$issues+=,$f.Path}}
  $script:GitAudit.Notes=@($issues|Select-Object -Unique)
  if($readmeOk -and -not $issues.Count){Award '6.2' 3 ('README в коммите содержит фактические адреса/порты; явные запрещённые файлы/ключи не найдены ограниченной проверкой. '+$script:GitAudit.Remote+' Качество инструкции, секреты и передачу подтверждает жюри.')}
  else{Event 'README и передача' 'НП' 'README не содержит все адреса/порты либо есть файлы, требующие проверки. Значения возможных секретов не выводятся.'}
  Event 'Git HEAD' 'ДА' ('Прочитан зафиксированный коммит '+$commit.Substring(0,12)+'. Незаписанные в коммит файлы не учитывались. '+$script:GitAudit.Remote)
 }catch{Event 'Git' 'НП' 'Не удалось прочитать существующий репозиторий и коммит. Нужны локальный клон с .git и установленный Git; ничего не клонировалось и не изменялось.'}
}
