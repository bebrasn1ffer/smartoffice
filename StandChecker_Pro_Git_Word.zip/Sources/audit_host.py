# Fixed read-only audit. Does not execute scripts from the student's project.
import subprocess,json,os,hashlib

def run(argv):
 try:
  p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=15,text=True)
  return p.returncode,p.stdout[:1500000]
 except Exception:return -1,''
result={'containers':[],'services':[],'files':[]}
def filehash(path,scope,kind):
 try:
  if not os.path.isfile(path) or os.path.getsize(path)>1500000:return
  text=open(path,'rb').read().decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n')
  result['files'].append({'name':os.path.basename(path),'scope':scope,'kind':kind,'hash':hashlib.sha256(text.encode()).hexdigest()})
 except Exception:pass
code,ids=run(['docker','ps','-q'])
result['docker_access']=code==0
if code==0 and ids.split():
 code,raw=run(['docker','inspect']+ids.split())
 if code==0:
  for x in json.loads(raw):
   labels=x.get('Config',{}).get('Labels') or {};cfgs=labels.get('com.docker.compose.project.config_files','')
   for path in cfgs.split(','):
    if path:filehash(path,labels.get('com.docker.compose.service',''),'compose')
   for mount in x.get('Mounts',[]):
    if mount.get('Type')=='bind'and str(mount.get('Destination','')).endswith(('.js','.py')):filehash(mount.get('Source',''),labels.get('com.docker.compose.service',''),'source')
   result['containers'].append({'id':x['Id'],'name':x.get('Name',''),'image':x.get('Config',{}).get('Image',''),'service':labels.get('com.docker.compose.service',''),'compose_exists':bool(cfgs)and all(os.path.isfile(p)for p in cfgs.split(',')),'mounts':x.get('Mounts',[]),'ports':x.get('NetworkSettings',{}).get('Ports',{})})
for unit in ['prometheus.service','grafana-server.service','grafana.service']:
 code,text=run(['systemctl','show',unit,'-p','LoadState','-p','ActiveState','-p','MainPID','-p','FragmentPath'])
 d=dict(line.split('=',1)for line in text.splitlines()if'='in line)
 if d.get('LoadState')!='loaded':continue
 try:
  pid=int(d.get('MainPID',0));cmd=open('/proc/%s/cmdline'%pid,'rb').read().replace(b'\0',b' ').decode(errors='replace')if pid>0 else''
 except Exception:cmd=''
 filehash(d.get('FragmentPath',''),unit,'unit')
 if unit=='prometheus.service':
  try:
   argv=open('/proc/%s/cmdline'%pid,'rb').read().decode().split('\0')
   for i,arg in enumerate(argv):
    if arg.startswith('--config.file='):filehash(arg.split('=',1)[1],unit,'config')
    elif arg=='--config.file'and i+1<len(argv):filehash(argv[i+1],unit,'config')
  except Exception:pass
 result['services'].append({'unit':unit,'active':d.get('ActiveState')=='active','command':cmd[:500],'unit_file':d.get('FragmentPath','')})
print(json.dumps(result,ensure_ascii=False))
